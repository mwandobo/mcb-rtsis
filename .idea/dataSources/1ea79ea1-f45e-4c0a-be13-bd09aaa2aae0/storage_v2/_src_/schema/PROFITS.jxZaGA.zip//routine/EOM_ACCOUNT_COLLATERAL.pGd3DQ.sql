CREATE PROCEDURE EOM_ACCOUNT_COLLATERAL ()
  SPECIFIC SQL160620112634160
  LANGUAGE SQL
  NOT DETERMINISTIC
  EXTERNAL ACTION
  MODIFIES SQL DATA
  CALLED ON NULL INPUT
  INHERIT SPECIAL REGISTERS
  OLD SAVEPOINT LEVEL
BEGIN
DELETE eom_account_collateral
WHERE  eom_date = (SELECT scheduled_date FROM bank_parameters);
INSERT INTO eom_account_collateral (
               account_number
              ,account_cd
              ,reval_curr_fix_rat
              ,reval_init_fix_rat
              ,reval_init_sv
              ,revaluation_currid
              ,yield_utilised_amn
              ,yield_limit_amn
              ,yield_perc
              ,cb_insurance_amn
              ,address
              ,afm_no
              ,dep_acc_ind
              ,unit_code
              ,note_status
              ,issuer_account
              ,bank_code
              ,internal_sn
              ,items_cnt
              ,prft_account
              ,insertion_dt
              ,entry_status
              ,profits_system
              ,reference_number
              ,est_value_amn
              ,est_insurance_amn
              ,user_code
              ,expiry_dt
              ,tmstamp
              ,first_name
              ,surname
              ,fk_customercust_id
              ,fk_collateralfk_co
              ,fk_collateralfk_un
              ,fk_collateralcolla
              ,fk_collateral_tfk
              ,fk_currencyid_curr
              ,eom_date
              ,nrm_balance
              ,ov_balance
              ,lg_amount_bal
              ,default_amn
              ,tot_est_value_amn
              ,reval_chrg_amn
              ,monitoring_unit
              ,collateral_fk_unitcode
              ,collateral_sn
              ,collateral_status
              ,acct_key)
   SELECT b.account_number
         ,b.account_cd
         ,c.reval_curr_fix_rat
         ,c.reval_init_fix_rat
         ,c.reval_init_sv
         ,c.revaluation_currid
         ,c.yield_utilised_amn
         ,c.yield_limit_amn
         ,c.yield_perc
         ,c.cb_insurance_amn
         ,address
         ,afm_no
         ,dep_acc_ind
         ,unit_code
         ,note_status
         ,issuer_account
         ,bank_code
         ,internal_sn
         ,c.items_cnt
         ,prft_account
         ,c.insertion_dt
         ,entry_status
         ,profits_system
         ,reference_number
         ,est_value_amn
         ,est_insurance_amn
         ,c.user_code
         ,expiry_dt
         ,c.tmstamp
         ,first_name
         ,surname
         ,fk_customercust_id
         ,fk_collateralfk_co
         ,fk_collateralfk_un
         ,fk_collateralcolla
         ,d.fk_collateral_tfk
         ,d.fk_currencyid_curr AS id_currency
         , (SELECT scheduled_date FROM bank_parameters) AS eom_date
         ,0 AS nrm_balance
         ,0 AS ov_balance
         ,0 AS lg_amount_bal
         ,0 AS default_amn
         ,d.tot_est_value_amn
         ,d.reval_chrg_amn
         ,d.monitoring_unit
         ,d.fk_unitcode collateral_fk_unitcode
         ,d.collateral_sn
         ,collateral_status
         ,b.account_ser_num
   FROM   profits_account b, r_account_collater c, r_collateral d
   WHERE      b.account_number = c.prft_account
          AND b.prft_system = c.profits_system
          AND c.fk_collateralfk_un = d.fk_unitcode
          AND c.fk_collateralfk_co = d.fk_collateral_tfk
          AND c.fk_collateralcolla = d.collateral_sn
          AND c.entry_status = '1';
END;

