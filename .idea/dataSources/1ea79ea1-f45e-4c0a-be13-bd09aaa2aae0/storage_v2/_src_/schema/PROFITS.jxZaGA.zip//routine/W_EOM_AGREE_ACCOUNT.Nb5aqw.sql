CREATE PROCEDURE W_EOM_AGREE_ACCOUNT ( )
  SPECIFIC SQL160620112634261
  LANGUAGE SQL
  NOT DETERMINISTIC
  EXTERNAL ACTION
  MODIFIES SQL DATA
  CALLED ON NULL INPUT
  INHERIT SPECIAL REGISTERS
  OLD SAVEPOINT LEVEL
BEGIN
DELETE w_eom_agree_account
WHERE  eom_date = (SELECT scheduled_date FROM bank_parameters);
INSERT INTO w_eom_agree_account (
               acct_key
              ,eom_date
              ,account_number
              ,prft_system
              ,account_cd
              ,agr_unit
              ,agr_year
              ,agr_sn
              ,agr_membership_sn
              ,user_code
              ,agr_status
              ,agr_lc_indicator
              ,agr_euro_indicator
              ,agr_fc_indicator
              ,agr_issue_dt
              ,agr_signing_dt
              ,agr_limit
              ,agr_utilised_limit
              ,agr_blocked_limit
              ,agr_blocked_cnt
              ,agr_amendment_cnt
              ,agr_expiry_dt
              ,off_asgn_dt
              ,prv_officer
              ,prv_offic_asn_dt
              ,acc_dom_cnt
              ,acc_euro_zone_cnt
              ,acc_fc_cnt
              ,acc_active_cnt
              ,acc_open_exp_dt
              ,acc_kind
              ,agr_comments
              ,tmstamp
              ,one_account_flg
              ,fk_cust_addressfk
              ,fk_cust_addressser
              ,fk_agreement_tyfk
              ,currency_id
              ,fk_generic_detafk
              ,fk_generic_detaser
              ,agr_limit_ind
              ,fk_bankemployeeid
              ,fk0bankemployeeid
              ,history_cnt
              ,history_curr_sn
              ,agr_annex_dt
              ,additional_cnt
             ,pend_final_dt
              ,amn_pend_sts
              ,agr_amn_pending
              ,acc_dom_new_cnt
              ,acc_eurzon_new_cnt
              ,acc_active_new_cnt
              ,acc_fc_new_cnt
              ,agr_extra_comments)
   SELECT account_ser_num acct_key
         , (SELECT scheduled_date FROM bank_parameters) AS eom_date
         ,b.account_number
         ,b.prft_system
         ,b.account_cd
         ,c.fk_unitcode agr_unit
         ,b.agr_year
         ,b.agr_sn
         ,b.agr_membership_sn
         ,c.user_code
         ,c.agr_status
         ,c.agr_lc_indicator
         ,c.agr_euro_indicator
         ,c.agr_fc_indicator
         ,c.agr_issue_dt
         ,c.agr_signing_dt
         ,c.agr_limit
         ,c.agr_utilised_limit
         ,c.agr_blocked_limit
         ,c.agr_blocked_cnt
         ,c.agr_amendment_cnt
         ,c.agr_expiry_dt
         ,c.off_asgn_dt
         ,c.prv_officer
         ,c.prv_offic_asn_dt
         ,c.acc_dom_cnt
         ,c.acc_euro_zone_cnt
         ,c.acc_fc_cnt
         ,c.acc_active_cnt
         ,c.acc_open_exp_dt
         ,c.acc_kind
         ,c.agr_comments
         ,c.tmstamp
         ,c.one_account_flg
         ,c.fk_cust_addressfk
         ,c.fk_cust_addressser
         ,c.fk_agreement_tyfk
         ,c.fk_currencyid_curr AS currency_id
         ,c.fk_generic_detafk
         ,c.fk_generic_detaser
         ,c.agr_limit_ind
         ,c.fk_bankemployeeid
         ,c.fk0bankemployeeid
         ,c.history_cnt
         ,c.history_curr_sn
         ,c.agr_annex_dt
         ,c.additional_cnt
         ,c.pend_final_dt
         ,c.amn_pend_sts
         ,c.agr_amn_pending
         ,c.acc_dom_new_cnt
         ,c.acc_eurzon_new_cnt
         ,c.acc_active_new_cnt
         ,c.acc_fc_new_cnt
         ,c.agr_extra_comments
   FROM   r_agreement c
          JOIN profits_account b
             ON (    b.agr_unit = c.fk_unitcode
                 AND b.agr_year = c.agr_year
                 AND b.agr_sn = c.agr_sn
                 AND b.agr_membership_sn = c.agr_membership_sn)
   WHERE  b.prft_system = 19;
END;

