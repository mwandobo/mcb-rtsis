CREATE PROCEDURE EOM_CUSTOMER_CREDIT_LI ( )
  SPECIFIC SQL160620112636369
  LANGUAGE SQL
  NOT DETERMINISTIC
  EXTERNAL ACTION
  MODIFIES SQL DATA
  CALLED ON NULL INPUT
  INHERIT SPECIAL REGISTERS
  OLD SAVEPOINT LEVEL
BEGIN
DELETE eom_customer_credit_li
WHERE  eom_date = (SELECT scheduled_date FROM bank_parameters);
INSERT INTO eom_customer_credit_li (
               eom_date
              ,crline_amount
              ,entry_status
              ,evaluation_dt
              ,expiry_date
              ,fk_currencyid_curr
              ,fk_customercust_id
              ,fk_generic_detafk
              ,fk_generic_detaser
              ,fk_unitcode
              ,fk_usrcode
              ,history_cnt
              ,intracom_flg
              ,reevaluation_dt
              ,tmstamp
              ,utilised_amount
              ,euro_crline_amount
              ,euro_utilised_amount
              ,fixing_rate)
   SELECT (SELECT scheduled_date FROM bank_parameters) AS eom_date
         ,crline_amount
         ,entry_status
         ,evaluation_dt
         ,expiry_date
         ,fk_currencyid_curr
         ,fk_customercust_id
         ,fk_generic_detafk
         ,fk_generic_detaser
         ,fk_unitcode
         ,fk_usrcode
         ,history_cnt
         ,intracom_flg
         ,reevaluation_dt
         ,tmstamp
         ,utilised_amount
         ,crline_amount * rate AS euro_crline_amount
         ,utilised_amount * rate AS euro_utilised_amount
         ,d.reverse_rate AS fixing_rate
   FROM   customer_credit_li c
          INNER JOIN bank_parameters p ON 1 = 1
          LEFT JOIN w_eom_fixing_rate d
             ON     d.currency_id = c.fk_currencyid_curr
                AND d.eom_date = p.scheduled_date;
END;

