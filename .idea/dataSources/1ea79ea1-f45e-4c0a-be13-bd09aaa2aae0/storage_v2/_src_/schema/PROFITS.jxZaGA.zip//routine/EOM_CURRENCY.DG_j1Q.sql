CREATE PROCEDURE EOM_CURRENCY ( )
  SPECIFIC SQL160620112636368
  LANGUAGE SQL
  NOT DETERMINISTIC
  EXTERNAL ACTION
  MODIFIES SQL DATA
  CALLED ON NULL INPUT
  INHERIT SPECIAL REGISTERS
  OLD SAVEPOINT LEVEL
BEGIN
DELETE eom_currency
WHERE  eom_date = (SELECT scheduled_date FROM bank_parameters);
INSERT INTO eom_currency (
               eom_date
              ,id_currency
              ,iso_code
              ,euro_locked_rate
              ,euro_identifier
              ,entry_status
              ,national_flag
              ,short_descr
              ,description)
   SELECT (SELECT scheduled_date FROM bank_parameters) AS eom_date
         ,id_currency
         ,iso_code
         ,euro_locked_rate
         ,euro_identifier
         ,entry_status
         ,national_flag
         ,short_descr
         ,description
   FROM   currency;
END;

