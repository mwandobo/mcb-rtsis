CREATE PROCEDURE W_DIM_GL_ACCOUNT ( )
  SPECIFIC SQL160620112633552
  LANGUAGE SQL
  NOT DETERMINISTIC
  EXTERNAL ACTION
  MODIFIES SQL DATA
  CALLED ON NULL INPUT
  INHERIT SPECIAL REGISTERS
  OLD SAVEPOINT LEVEL
BEGIN
MERGE INTO w_dim_gl_account a
USING      (SELECT account_id, level0 account_level, descr description
            FROM   glg_account) b
ON         (a.account_id = b.account_id)
WHEN NOT MATCHED
THEN
   INSERT     (account_id, account_level, description)
   VALUES     (b.account_id, b.account_level, b.description)
WHEN MATCHED
THEN
   UPDATE SET
      a.account_level = b.account_level, a.description = b.description;
END;

