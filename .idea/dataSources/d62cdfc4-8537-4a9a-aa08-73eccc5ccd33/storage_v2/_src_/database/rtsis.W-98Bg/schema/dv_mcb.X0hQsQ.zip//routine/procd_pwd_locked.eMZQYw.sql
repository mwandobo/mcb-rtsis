create function procd_pwd_locked(i_domain_id text, i_user_id text, OUT o_flag text, OUT p_error text) returns record
    language plpgsql
as
$$

DECLARE
    P_UPWDINV_INVALID_COUNT NUMERIC(2);
    P_COUNT NUMERIC(2);
    V_SQL CHARACTER VARYING(4000);
    P_UNSUCC_ATTEMPTS NUMERIC(2);
    P_CURRENT_DATE CHARACTER VARYING(20);
BEGIN
    O_FLAG := '0';
    P_ERROR := null ;
    P_UNSUCC_ATTEMPTS := 0;
    P_UPWDINV_INVALID_COUNT := 0;

    BEGIN
        SELECT
            TO_CHAR(currentbd, 'DD-MM-YYYY')
            INTO STRICT P_CURRENT_DATE
            FROM dv_mcb.sysconf003;
       -- RAISE DEBUG USING MESSAGE = CONCAT_WS('', 'P_CURRENT_DATE = ', P_CURRENT_DATE);
        SELECT
            lock_uid_noof_atmpts
            INTO STRICT P_UNSUCC_ATTEMPTS
            FROM dv_mcb.sysconf002
            WHERE eff_date = (SELECT
                MAX(eff_date)
                FROM dv_mcb.sysconf002
                WHERE eff_date <= (SELECT
                    TO_DATE(P_CURRENT_DATE, 'DD/MM/YYYY')) AND auser IS NOT NULL);
        EXCEPTION
            WHEN others THEN
                P_ERROR := 'Online System Control Parameter Not Defined';
                O_FLAG := '0';
                RETURN;
    END;

    BEGIN
       /* SELECT
            upwdinv_invalid_count
            INTO STRICT P_UPWDINV_INVALID_COUNT
            FROM absa.users012
            WHERE suborgcode = I_DOMAIN_ID AND upwdinv_user_id = I_USER_ID; */

P_UPWDINV_INVALID_COUNT :=0;
 P_COUNT := 0;
 
    if(P_UPWDINV_INVALID_COUNT IS NOT NULL) then 
    P_COUNT := P_COUNT + 1; END IF;
    if(P_UPWDINV_INVALID_COUNT > P_UNSUCC_ATTEMPTS) then
    P_COUNT := P_COUNT + 1; END IF;
    if(P_UNSUCC_ATTEMPTS > 0) then
    P_COUNT := P_COUNT + 1; END IF;
    
    /*
     IF ((P_UPWDINV_INVALID_COUNT IS NOT NULL) AND (P_UPWDINV_INVALID_COUNT > P_UNSUCC_ATTEMPTS) AND (P_UNSUCC_ATTEMPTS > 0)) THEN 
     */
     
     if (P_COUNT > 2 )then  
 
           UPDATE dv_mcb.users002 SET status_flag = '1'
           WHERE suborgcode = I_DOMAIN_ID AND user_id = I_USER_ID AND status_date = P_CURRENT_DATE::TIMESTAMP WITHOUT TIME ZONE;
     P_UPWDINV_INVALID_COUNT := 3;  
      
           O_FLAG := '1';
        END IF;
        /*
        [5035 - Severity CRITICAL - Your code ends a transaction inside a block with exception handlers. Revise your code to move transaction control to the application side and try again.]
        COMMIT
        */
        EXCEPTION
            WHEN others THEN
                P_ERROR := '';
                O_FLAG := '0';
                RETURN;
    END;
/* SP_USER_PWD_LOCKED */
END;
$$;

alter function procd_pwd_locked(text, text, out text, out text) owner to postgres;

