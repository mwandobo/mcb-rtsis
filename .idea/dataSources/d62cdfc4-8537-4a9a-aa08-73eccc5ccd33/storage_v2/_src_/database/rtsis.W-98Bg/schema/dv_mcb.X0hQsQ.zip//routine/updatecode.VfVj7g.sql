create function updatecode() returns void
    language plpgsql
as
$$
DECLARE
  V_SUBORGCODE VARCHAR := 'MCB';
BEGIN
  SELECT SUBORGCODE INTO V_SUBORGCODE FROM sysconf001 LIMIT 1;

  UPDATE currency001 SET suborgcode = V_SUBORGCODE;
  UPDATE eventexecutor SET suborgcode = V_SUBORGCODE;
  UPDATE module_code001 SET suborgcode = V_SUBORGCODE;
  UPDATE webservice001 SET suborgcode = V_SUBORGCODE;
  UPDATE webservice002 SET suborgcode = V_SUBORGCODE;
  UPDATE verify002 SET suborgcode = V_SUBORGCODE;
  UPDATE users0001 SET suborgcode = V_SUBORGCODE;
  UPDATE users008 SET suborgcode = V_SUBORGCODE;
  UPDATE users009 SET suborgcode = V_SUBORGCODE;
  UPDATE users012 SET suborgcode = V_SUBORGCODE;
  UPDATE users014 SET suborgcode = V_SUBORGCODE;
  UPDATE submodule_code001 SET suborgcode = V_SUBORGCODE;
  UPDATE suboff001 SET suborgcode = V_SUBORGCODE;
  UPDATE sysconf001 SET suborgcode = V_SUBORGCODE;
  UPDATE sysconf003 SET suborgcode = V_SUBORGCODE;
  UPDATE sysconf004 SET suborgcode = V_SUBORGCODE;
  UPDATE menu005 SET syscode = V_SUBORGCODE;
  COMMIT;
END;
$$;

alter function updatecode() owner to postgres;

