create function rts001(info1 character varying, info2 character varying, info3 character varying, OUT o_serial text, OUT o_errmsg text) returns record
    language plpgsql
as
$$

DECLARE

    V_SUBORGCODE VARCHAR(10) := 0;
    V_COUNT NUMERIC(10) := 0;
	V_ID NUMERIC(10) := 0;
	reportingDate VARCHAR(100) := '';
	acquisitionDate VARCHAR(100) := '';
	currency VARCHAR(100) := '';
	usdcostvalue VARCHAR(100) := '';
	assetType VARCHAR(100) := '';
	assetCategory VARCHAR(100) := '';
	loop1 RECORD;
	
BEGIN
 
 SELECT SUBORGCODE into V_SUBORGCODE from dv_mcb.sysconf001;

 O_SERIAL := nextval('rtsis_report_serial');
 V_ID := nextval('rts003_id_seq');
 
 O_ERRMSG :='S';
     
   FOR loop1 IN (select * from dv_mcb.asset_master_view ) LOOP
	
       V_COUNT := V_COUNT+1;
	   
	    <<excep>>
        BEGIN   
		
		  acquisitionDate := TO_CHAR(loop1.acquisitiondate, 'DDMMYYYYHH24MI');
		  reportingDate := TO_CHAR(CURRENT_DATE, 'DDMMYYYYHH24MI');
		 
       exception when others then
       null;
       end excep;
	   
	   currency := loop1.currency;
           
           if(currency = 'TZS') then
              currency := '834';
		   end if;
		   
	   assetCategory := loop1.assetcategory;
           
           if(assetCategory = 'Leasehold-Improvement') then
              assetCategory := '2';
		   else
              assetCategory := '1'; 
		   end if;
		   
		 assetType := loop1.assetcategory;
           
           if(assetType = 'Furniture') then
              assetType := '2';
		   elsif(assetType = 'Equipment') then
              assetType := '3'; 
		   elsif(assetType = 'Leasehold-Improvement') then
              assetType := '5'; 
		   elsif(assetType = 'Computers') then
              assetType := '7'; 
		   elsif(assetType = 'Motorvehicles') then
              assetType := '4'; 
		   elsif(assetType ='Intangible Assets-Corebanking Software' or assetType='Intangible Assets-Other Software') then
		   	  assetType := '24';
		   end if;
		
		usdcostvalue := '0.00';  
	   
	   --Leasehold-Improvement
	   
	   INSERT INTO REPORT002(SUBORGCODE, SERIAL, COLUMN1, COLUMN2, COLUMN3, COLUMN4, COLUMN5, COLUMN6, COLUMN7, column8, column9, column10, column11, column12, column13, column14) 
	   VALUES(V_SUBORGCODE, O_SERIAL, 'D', INFO1, 'assetOwnedData', V_COUNT, reportingDate,assetCategory,assetType,acquisitionDate,'834',loop1.orgcostvalue,usdcostvalue,loop1.tzscostvalue,'0','0');
        

     END LOOP;

     IF V_COUNT <> 0 THEN
       
	    INSERT INTO report002(suborgcode, serial, column1, column2, column3, column4, column5, column6, column7, column8, column9, column10, column11, column12, column13, column14)
        VALUES (V_SUBORGCODE, O_SERIAL, 'C', INFO1, 'assetOwnedData', 'serial', 'reportingDate', 'assetCategory', 'assetType','acquisitionDate','currency','orgCostValue','usdCostValue','tzsCostValue','botProvision','allowanceProbableLoss');

        INSERT INTO report002(suborgcode, serial, column1, column2, column3)
        VALUES (V_SUBORGCODE, O_SERIAL, 'H', INFO1, 'assetOwnedData');
		
		INSERT INTO dv_mcb.rts003(id, suborgcode, module, submodule, servicecd, no_of_records, created_by, created_on,is_uploaded, is_pushed, report_serial, source_type)
	    VALUES (V_ID,V_SUBORGCODE, 'asset', 'assetOwnedData', INFO1, V_COUNT, 'system', NOW(),1, 0, O_SERIAL, 'DB');
        
    
	END IF;

         O_SERIAL := O_SERIAL;
         O_ERRMSG := O_ERRMSG;

    -- Return the result
    
EXCEPTION
    WHEN OTHERS THEN
       O_SERIAL := NULL;
       O_ERRMSG := SQLERRM;
        
END;
$$;

alter function rts001(varchar, varchar, varchar, out text, out text) owner to postgres;

