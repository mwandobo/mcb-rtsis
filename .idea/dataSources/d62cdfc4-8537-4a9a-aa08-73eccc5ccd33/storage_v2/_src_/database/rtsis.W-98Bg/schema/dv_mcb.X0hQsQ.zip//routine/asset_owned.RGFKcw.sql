create function asset_owned(info1 character varying, info2 character varying, info3 character varying) returns asset_owned_result
    language plpgsql
as
$$
DECLARE
    V_SUBORGCODE VARCHAR(10) := '0';
    V_COUNT INT := 0;
    O_SERIAL INT;
    O_ERRMSG VARCHAR := 'S';
BEGIN
    SELECT SUBORGCODE INTO V_SUBORGCODE FROM sysconf001 LIMIT 1;

    O_SERIAL := NEXTVAL('rtsis_report_serial'); -- Use NEXTVAL function to get the next value from the sequence

    V_COUNT := V_COUNT + 1;

    INSERT INTO report002(suborgcode, serial, column1, column2, column3, column4, column5, column6, column7)
    VALUES (V_SUBORGCODE, O_SERIAL, 'D', INFO1, 'assetOwned', V_COUNT, 310820231123, 10000, 56);

    IF V_COUNT <> 0 THEN
        INSERT INTO report002(suborgcode, serial, column1, column2, column3, column4, column5, column6, column7)
        VALUES (V_SUBORGCODE, O_SERIAL, 'C', INFO1, 'assetOwned', 'serial', 'reportingDate', 'transactionDate', 'govInstitutionName');

        INSERT INTO report002(suborgcode, serial, column1, column2, column3)
        VALUES (V_SUBORGCODE, O_SERIAL, 'H', INFO1, 'assetOwned');
		
		 INSERT INTO dv_mcb.rts003(
             SUBORGCODE, MODULE, SUBMODULE, SERVICECD, NO_OF_RECORDS, CREATED_BY, created_on,IS_UPLOADED ,IS_PUSHED, REPORT_SERIAL, SOURCE_TYPE
        ) VALUES (
             V_SUBORGCODE, 'asset', 'assetOwned', INFO1, V_COUNT, 'system', NOW(), 1 , 0, O_SERIAL, 'DB'
        );
    END IF;

    -- You can handle additional logic here

    -- Return the results as a composite type
    RETURN (O_SERIAL, O_ERRMSG);

EXCEPTION
    WHEN OTHERS THEN
        O_ERRMSG := SQLERRM;
        -- Return the error message if an exception occurs
        RETURN (NULL, O_ERRMSG);
END;
$$;

alter function asset_owned(varchar, varchar, varchar) owner to postgres;

