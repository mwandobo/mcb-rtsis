create function updateauthstatus(programid character varying, keyvalue character varying, userid character varying, cbddate character varying, authstatus character, OUT confirmation character varying) returns character varying
    language plpgsql
as
$$
 DECLARE
  XMLSTRING VARCHAR(500) = NULL;
  COUNTER   INT = 0;
BEGIN



  IF (UPPER(TRIM(PROGRAMID)) = 'EBBILLPAY') THEN

      IF(UPPER(TRIM(AUTHSTATUS)) = 'STATUS') THEN
         -- SQLINES LICENSE FOR EVALUATION USE ONLY
         SELECT A.STATUS INTO CONFIRMATION FROM AUTH001 A
         WHERE uPper(A.AUTHQ_PGM_ID) = upper(PROGRAMID)
               AND A.AUTHQ_MAIN_PK = KEYVALUE;
               -- SQLINES DEMO *** Y = USERID;
        IF CONFIRMATION IS NULL THEN
          CONFIRMATION := 'NO';
        END IF;

      ELSE
          UPDATE AUTH001 A SET A.STATUS = AUTHSTATUS
            WHERE uPper(A.AUTHQ_PGM_ID) = upper(PROGRAMID)
               AND A.AUTHQ_MAIN_PK = KEYVALUE;
               -- SQLINES DEMO *** Y = USERID;
               CONFIRMATION := 'S';
          /* COMMIT; */
      END IF;
  END IF;

    IF (UPPER(TRIM(PROGRAMID)) IN ('SIMBANETPAY' , 'MSCPAY', 'UDOMPAY' ,'SJUIT', 'GEPGPAY','GEPGPAYNEW','TAXCOLL','DERMALOGPAY')) THEN

      IF(UPPER(TRIM(AUTHSTATUS)) = 'STATUS') THEN
         -- SQLINES LICENSE FOR EVALUATION USE ONLY
         SELECT A.STATUS INTO CONFIRMATION FROM AUTH001 A
         WHERE uPper(A.AUTHQ_PGM_ID) = upper(PROGRAMID)
               AND A.AUTHQ_MAIN_PK = KEYVALUE;
               -- SQLINES DEMO *** Y = USERID;
        IF CONFIRMATION IS NULL THEN
          CONFIRMATION := 'NO';
        END IF;

      ELSE
          UPDATE AUTH001 A SET A.STATUS = AUTHSTATUS
            WHERE uPper(A.AUTHQ_PGM_ID) = upper(PROGRAMID)
               AND A.AUTHQ_MAIN_PK = KEYVALUE;
               -- SQLINES DEMO *** Y = USERID;
               CONFIRMATION := 'S';
          /* COMMIT; */
      END IF;
  END IF;




END;
$$;

alter function updateauthstatus(varchar, varchar, varchar, varchar, char, out varchar) owner to postgres;

