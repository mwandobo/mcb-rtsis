create function proc_cbspostnew(i_suborgcode text, i_chcode text, i_paytype text, i_flow text, i_refno text, i_tranamnt text, i_trancurr text, i_dbaccount text, i_craccount text, i_chrgamnt text, i_chrgcurr text, i_reqsl text, OUT o_billamount text, OUT o_chrgamount text, OUT o_dbcurr text, OUT o_dbaccount text, OUT o_craccount text, OUT o_crchrgaccount text, OUT o_narration text, OUT o_reqcode text, OUT o_brncode text, OUT o_result text, OUT o_message text) returns record
    language plpgsql
as
$$

DECLARE

    v_debitcurr CHARACTER VARYING(10) := NULL;

    v_debibrn CHARACTER VARYING(50) := NULL;

    v_creditcurr CHARACTER VARYING(10) := NULL;

    v_creditbrn CHARACTER VARYING(50) := NULL;

    v_chrg_amount CHARACTER VARYING(50) := NULL;

    v_chrg_amount2 CHARACTER VARYING(50) := NULL;

    v_o_chrg_amount CHARACTER VARYING(50) := NULL;

    v_chrg_account CHARACTER VARYING(50) := NULL;

    v_chrg_account2 CHARACTER VARYING(50) := NULL;

    v_src_actype CHARACTER VARYING(50) := NULL;

    v_dest_actype CHARACTER VARYING(50) := NULL;

    v_req_date CHARACTER VARYING(20) := NULL;

    v_invoice CHARACTER VARYING(100) := NULL;

    V_COUNT NUMERIC(10) := 0;

    v_Subref CHARACTER VARYING(50) := NULL;

    v_accountname CHARACTER VARYING(50) := NULL;

              

               v_error_stack text := NULL;

BEGIN

    /* ************************************************** TIPS ************************************************** */

    IF (I_PAYTYPE = 'TIPS' AND I_TRANCURR = 'TZS') THEN

        IF (I_FLOW = 'O') THEN

            SELECT

                r.crgl

                INTO STRICT O_CRACCOUNT

                FROM  ledgermap AS r

                WHERE r.program = I_PAYTYPE AND r.usergroup = I_FLOW AND r.trantype = 'T' AND r.dcflg = 'C';

            SELECT

                w.s_brncode, w.s_actype, w.d_actype, w.reqdate

                INTO STRICT v_debibrn, v_src_actype, v_dest_actype, v_req_date

                FROM  pay001 AS w

                WHERE w.suborgcode = I_SUBORGCODE AND w.chcode = I_CHCODE AND w.paytype = I_PAYTYPE AND w.reqrefno = I_REFNO AND w.reqsl = I_REQSL;

            v_debibrn := 1;

            v_creditbrn := v_debibrn;

            O_BILLAMOUNT := I_TRANAMNT;

            O_DBCURR := 'TZS';

            O_REQCODE := '';

            O_CHRGAMOUNT := v_chrg_amount;

            O_DBACCOUNT := I_DBACCOUNT;

            O_BRNCODE := CONCAT_WS('', v_debibrn, '|', v_debibrn, '|', v_creditbrn, '|');

            O_NARRATION := CONCAT_WS('', 'TIPS: SOURCE: ', I_DBACCOUNT, ' DEST: ', I_CRACCOUNT, ' AMT: ', I_TRANAMNT);

            V_COUNT := 0;

            /* SELECT count(*) into V_COUNT FROM TRANSACTIONS T WHERE trunc(T.SYSTEMDATE) = trunc(sysdate) and T.CHREFNO = I_REFNO; */

 

            IF (V_COUNT = 0) THEN

                V_COUNT := V_COUNT + 1;

                INSERT INTO  transactions (suborgcode, trantype, trancode, systemdate, transeq, legsl, branchcd, trandate, chcode, chrefno, dbcr, amount, trancurr, sysamount, syscurr, accountno, iban, swiftcd, ledgerno, paytype, charges, chgcode, remarks, euser, edate, auser, adate, cuser, cdate, status, invoiceno, syscode, paysl, addinfo1, addinfo5)

                VALUES (I_SUBORGCODE, 'TRANSFER', 'TD', current_timestamp, V_COUNT, 1, v_debibrn, current_date, I_CHCODE, I_REFNO, 'D', TO_NUMBER(O_BILLAMOUNT,'9999999999'), I_TRANCURR,  TO_NUMBER(I_TRANAMNT,'9999999999'), I_TRANCURR, I_DBACCOUNT, NULL, NULL, NULL, I_PAYTYPE, NULL, NULL, O_NARRATION, I_CHCODE, current_timestamp, I_CHCODE, current_timestamp, NULL, NULL, 'POSTED', NULL, 'HP',  TO_NUMBER(I_REQSL,'9999999999'), 'PRINCIPLE',  TO_NUMBER(I_REFNO,'9999999999'));

                INSERT INTO  transactions (suborgcode, trantype, trancode, systemdate, transeq, legsl, branchcd, trandate, chcode, chrefno, dbcr, amount, trancurr, sysamount, syscurr, accountno, iban, swiftcd, ledgerno, paytype, charges, chgcode, remarks, euser, edate, auser, adate, cuser, cdate, status, invoiceno, syscode, paysl, addinfo1, addinfo5)

                VALUES (I_SUBORGCODE, 'TRANSFER', 'TC', current_timestamp, V_COUNT, 2, v_creditbrn, current_date, I_CHCODE, I_REFNO, 'C', TO_NUMBER(O_BILLAMOUNT,'9999999999'), I_TRANCURR,  TO_NUMBER(I_TRANAMNT,'9999999999'), I_TRANCURR, NULL, NULL, NULL, O_CRACCOUNT, I_PAYTYPE, NULL, NULL, O_NARRATION, I_CHCODE, current_timestamp, I_CHCODE, current_timestamp, NULL, NULL, 'POSTED', NULL, 'HP',  TO_NUMBER(I_REQSL,'9999999999'), 'PRINCIPLE', TO_NUMBER(I_REFNO,'9999999999'));

            END IF;

        END IF;

 

        IF (I_FLOW = 'I') THEN

            SELECT

                r.dbgl

                INTO STRICT O_DBACCOUNT

                FROM  ledgermap AS r

                WHERE r.program = I_PAYTYPE AND r.usergroup = I_FLOW AND r.trantype = 'T' AND r.dcflg = 'D';

            SELECT

                w.d_brncode, w.reqdate

                INTO STRICT v_creditbrn, v_req_date

                FROM  pay001 AS w

                WHERE w.suborgcode = I_SUBORGCODE AND w.chcode = I_CHCODE AND w.paytype = I_PAYTYPE AND w.reqrefno = I_REFNO AND w.reqsl = I_REQSL;

            SELECT

                r.s_acname

                INTO STRICT v_accountname

                FROM  request002 AS r

                WHERE r.reqrefno = I_REFNO;

            v_Subref := substr(I_REFNO, 1, 15);

            v_creditbrn := 1;

            v_debibrn := v_creditbrn;

            O_BILLAMOUNT := I_TRANAMNT;

            O_DBCURR := 'TZS';

            O_REQCODE := '';

            O_CHRGAMOUNT := '';

            O_CRACCOUNT := I_CRACCOUNT;

            O_BRNCODE := CONCAT_WS('', v_debibrn, '|', v_debibrn, '|', v_creditbrn, '|');

            /* O_NARRATION := 'TIPS:REF: ' || I_REFNO || 'ACNAME: ' || v_accountname; */

            O_NARRATION := v_Subref;

            V_COUNT := 0;

            V_COUNT := V_COUNT + 1;

                     INSERT INTO  transactions (suborgcode, trantype, trancode, systemdate, transeq, legsl, branchcd, trandate, chcode, chrefno, dbcr, amount, trancurr, sysamount, syscurr, accountno, iban, swiftcd, ledgerno, paytype, charges, chgcode, remarks, euser, edate, auser, adate, cuser, cdate, status, invoiceno, syscode, paysl, addinfo1)

                       VALUES (I_SUBORGCODE, 'TRANSFER', 'TD', current_timestamp, V_COUNT, 1, v_debibrn, current_date, I_CHCODE, I_REFNO, 'D',  TO_NUMBER(O_BILLAMOUNT,'9999999999'), I_TRANCURR,  TO_NUMBER(I_TRANAMNT,'9999999999'), I_TRANCURR, NULL, NULL, NULL, O_DBACCOUNT, I_PAYTYPE, NULL, NULL, O_NARRATION, I_CHCODE, current_timestamp, I_CHCODE, current_timestamp, NULL, NULL, 'PENDING', NULL, 'HP',  TO_NUMBER(I_REQSL,'9999999999'), 'PRINCIPLE');

                        INSERT INTO  transactions (suborgcode, trantype, trancode, systemdate, transeq, legsl, branchcd, trandate, chcode, chrefno, dbcr, amount, trancurr, sysamount, syscurr, accountno, iban, swiftcd, ledgerno, paytype, charges, chgcode, remarks, euser, edate, auser, adate, cuser, cdate, status, invoiceno, syscode, paysl, addinfo1)

                       VALUES (I_SUBORGCODE, 'TRANSFER', 'TC', current_timestamp, V_COUNT, 2, v_creditbrn, current_date, I_CHCODE, I_REFNO, 'C',  TO_NUMBER(O_BILLAMOUNT,'9999999999'), I_TRANCURR,  TO_NUMBER(I_TRANAMNT,'9999999999'), I_TRANCURR, O_CRACCOUNT, NULL, NULL, NULL, I_PAYTYPE, NULL, NULL, O_NARRATION, I_CHCODE, current_timestamp, I_CHCODE, current_timestamp, NULL, NULL, 'PENDING', NULL, 'HP',  TO_NUMBER(I_REQSL,'9999999999'), 'PRINCIPLE');
             END IF;

    END IF;

              

END;

$$;

alter function proc_cbspostnew(text, text, text, text, text, text, text, text, text, text, text, text, out text, out text, out text, out text, out text, out text, out text, out text, out text, out text, out text) owner to postgres;

