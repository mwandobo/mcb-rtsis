create function sp_updpwd_gen_bk(custid text, userid text, hashed text, OUT errormsg text) returns text
    language plpgsql
as
$$

DECLARE
    P_CUST_ID CHARACTER VARYING(12);
    P_USER_ID CHARACTER VARYING(15);
    P_PIN2 CHARACTER VARYING(150);
    P_ERRMSG CHARACTER VARYING(100);
    PIN1 CHARACTER VARYING(4000);
    PIN2 CHARACTER VARYING(4000);
    P_STATUS CHARACTER VARYING(4000);
BEGIN
    P_ERRMSG := 'S';
    P_CUST_ID := 'MCB';
    P_USER_ID := USERID;
    P_PIN2 := HASHED;
    CALL  proc_sec(P_USER_ID, P_PIN2, PIN2, P_STATUS);
    UPDATE  users0001
    SET verify1 = P_PIN2, verify = PIN2
        WHERE suborgcode = P_CUST_ID AND userscd = P_USER_ID;
    UPDATE  users013
    SET first_pin = PIN1, second_pin = PIN2
        WHERE suborgcode = P_CUST_ID AND user_id = P_USER_ID;
    /*
    [5035 - Severity CRITICAL - Your code ends a transaction inside a block with exception handlers. Revise your code to move transaction control to the application side and try again.]
    commit
    */
    ERRORMSG := P_ERRMSG;
    EXCEPTION
        WHEN no_data_found THEN
            RAISE DEBUG USING MESSAGE = CONCAT_WS('', 'ERROR MESSAGE : ', P_ERRMSG);
        WHEN others THEN
            RAISE DEBUG USING MESSAGE = CONCAT_WS('', 'ERROR MESSAGE : ', P_ERRMSG);
END;
$$;

alter function sp_updpwd_gen_bk(text, text, text, out text) owner to postgres;

