create procedure proc_login_valid(IN p_suborgcode text, IN p_user_id text, IN p_password text, INOUT p_user_name text, INOUT p_mn_curr_business_date text, INOUT p_current_date text, INOUT p_role text, INOUT p_email text, INOUT p_passexpiry double precision, INOUT p_syscpm_min_uid_length double precision, INOUT p_syscpm_min_pwd_length double precision, INOUT p_syscpm_min_num_pwd double precision, INOUT p_syscpm_min_alpha_pwd double precision, INOUT p_error text, INOUT p_last_login_date_time text, INOUT p_frs_usr_pwd_chg double precision, INOUT p_syscpm_sess_tmout double precision, INOUT p_pwd_reset character, INOUT branchcd text, IN p_int_inta double precision DEFAULT 0, INOUT p_curr_code text DEFAULT NULL::text, INOUT p_cust_code text DEFAULT NULL::text, INOUT p_cust_name text DEFAULT NULL::text)
    language plpgsql
as
$$
DECLARE
    V_USER_SUSP_REL_FLAG CHARACTER(1);
    V_USER_LOCKED_FLAG CHARACTER(1);
    V_USERLEAVEDTL_LEAVE_FLG CHARACTER(1);
    V_SYSCPM_FORCE_PWD_CHG NUMERIC(4);
    V_SYSCPM_UW_UNSUC_ATMPTS NUMERIC(1);
    V_SYSCPM_LOCK_UID_NOOF_ATMPTS NUMERIC(1);
    V_SYSCPM_WORK_STN_REG_REQD CHARACTER(1);
    V_SYSCPM_USER_STN_RESTN_REQD CHARACTER(1);
    V_SYSCPM_AUTO_LOGOUT_SECS NUMERIC(5);
    V_CHANGE_DATE TIMESTAMP(0) WITHOUT TIME ZONE;
    V_CURR_DATE TIMESTAMP(0) WITHOUT TIME ZONE;
    V_MAX_DATE TIMESTAMP(0) WITHOUT TIME ZONE;
    V_USER_ENTD_ON TIMESTAMP(0) WITHOUT TIME ZONE;
    V_HIST_DATE TIMESTAMP(0) WITHOUT TIME ZONE;
    V_NUM_DAYS NUMERIC(5);
    X_COUNT NUMERIC(6);
    V_SALT CHARACTER VARYING(1000);
    V_PASSWORD CHARACTER VARYING(2048);
    V_ENCRYPTPASSWORD CHARACTER VARYING(2048);
    V_STATUS CHARACTER(1);
    V_ACTIVE_ROLE_CODE CHARACTER VARYING(6);
    V_ACTIVE_ROLE_DESCN CHARACTER VARYING(50);
    V_ROLE_DESCN CHARACTER VARYING(50);
    V_USER_INTERNAL_EXTERNAL CHARACTER(1);
    v_key_string CHARACTER VARYING(16);
    v_decrypted_string CHARACTER VARYING(2048);
    v_encrypted_string CHARACTER VARYING(2048);
    v_enc_pwd CHARACTER VARYING(16);
    V_ULHST_IN_DATE TIMESTAMP(0) WITHOUT TIME ZONE;
    V_SYSDATE TIMESTAMP(0) WITHOUT TIME ZONE;
    V_DIFF_DAYS NUMERIC(5);
    V_MAXPER_INACT_USED_ONCE NUMERIC(3);
    V_MAXPER_INACT_NOT_USED NUMERIC(3);
    V_USER_WORK_FROM_TIME NUMERIC(4);
    V_USER_WORK_UPTO_TIME NUMERIC(4);
    V_CHK_RECORD CHARACTER VARYING(1);
    V_DELETE_FLAG CHARACTER(1);
    V_DISB_ENAB_FLAG CHARACTER(1);
    V_AUTH_BY CHARACTER VARYING(20);
    V_USERID_EXPIRY NUMERIC(4);
    V_SYSCPMDATE TIMESTAMP(0) WITHOUT TIME ZONE;
    V_USERSID CHARACTER VARYING(8) := NULL;
    V_DIFF_DATE TIMESTAMP(0) WITHOUT TIME ZONE;
    V_INACT public.sysconf002.maxper_inact_not_used%TYPE;
    V_DIFF NUMERIC(3);
    V_WHERE CHARACTER(1);
    V_APPL CHARACTER VARYING(1);
    V_USER_LAST_MOD_BY CHARACTER VARYING(20);
    V_USER_LAST_MOD_ON TIMESTAMP(0) WITHOUT TIME ZONE;
    V_ROWSEP CHARACTER(2);
    V_COLSEP CHARACTER(2);
    V_CURR_CODE CHARACTER VARYING(3);
    V_CUST_CODE CHARACTER VARYING(15);
    V_CUST_NAME CHARACTER VARYING(100);
    V_DOMAIN_DISOLVE TIMESTAMP(0) WITHOUT TIME ZONE;
    V_CAT CHARACTER(1);
    AUTHORIZER CHARACTER VARYING(16);
    PASS_CODE CHARACTER VARYING(16);
    V_ROLE_ID CHARACTER VARYING(6);
BEGIN
    PERFORM aws_oracle_ext.packageinitialize(proutinename => 'public.proc_login_valid', pforce => TRUE);
    P_ERROR := 'S';
    P_PASSEXPIRY := 0;
    PERFORM aws_oracle_ext.setglobalvariable(proutinename => 'public.proc_login_valid', pvariable => 'V_USER_LOG_REASON', pval => 'Unsucessful Attempt'::CHARACTER VARYING(100));
    CALL public.pkg_intouch$sp_global(V_ROWSEP, V_COLSEP);

    <<INRAINTER>>
    BEGIN
        SELECT
            rolecd
            INTO STRICT V_ROLE_ID
            FROM public.users0001
            WHERE suborgcode = aws_oracle_ext.getglobalvariable(proutinename => 'public.proc_login_valid', pvariable => 'P_SUBORGCODE', ptp => NULL::VARCHAR(8000)) AND userscd = aws_oracle_ext.getglobalvariable(proutinename => 'public.proc_login_valid', pvariable => 'P_USER_ID', ptp => NULL::VARCHAR(8000));

        IF V_ROLE_ID IS NULL OR V_ROLE_ID = '' THEN
            P_ERROR := 'Invalid Access';
            RETURN;
        END IF;

        IF (V_ROLE_ID = 'MAKR' OR V_ROLE_ID = 'CHKR') THEN
            IF P_INT_INTA = 1 THEN
                P_ERROR := 'Invalid Access';
            END IF;
        ELSE
            NULL;
        END IF;
        EXCEPTION
            WHEN others THEN
                P_ERROR := 'Either User ID or Password you entered is Incorrect';
                RETURN;
    END;

    DECLARE
        P_MN_CURR_BUSINESS_DATE$490119229 VARCHAR(8000);
    BEGIN
        SELECT
            aws_oracle_ext.TO_CHAR(currentbd, 'DD/MM/YYYY'), currentbd, aws_oracle_ext.TO_CHAR(currentbd, 'DD-MM-YYYY')
            INTO STRICT P_MN_CURR_BUSINESS_DATE$490119229, V_CURR_DATE, P_CURRENT_DATE
            FROM public.sysconf003;
        PERFORM aws_oracle_ext.setglobalvariable(proutinename => 'public.proc_login_valid', pvariable => 'P_MN_CURR_BUSINESS_DATE', pval => P_MN_CURR_BUSINESS_DATE$490119229);
        EXCEPTION
            WHEN others THEN
                P_ERROR := 'Current Business Date Not Defined';
                RETURN;
    END;

    BEGIN
        SELECT
            forcepwdchg, uw_unsuc_atmpts, lock_uid_noof_atmpts, work_stn_reg_reqd, spcharcount, auto_logout_secs, minuserlength, minpasslength, min_num_pwd, minalphachar, maxper_inact_not_used, auto_logout_secs
            INTO STRICT V_SYSCPM_FORCE_PWD_CHG, V_SYSCPM_UW_UNSUC_ATMPTS, V_SYSCPM_LOCK_UID_NOOF_ATMPTS, V_SYSCPM_WORK_STN_REG_REQD, V_SYSCPM_USER_STN_RESTN_REQD, V_SYSCPM_AUTO_LOGOUT_SECS, P_SYSCPM_MIN_UID_LENGTH, P_SYSCPM_MIN_PWD_LENGTH, P_SYSCPM_MIN_NUM_PWD, P_SYSCPM_MIN_ALPHA_PWD, /* V_MAXPER_INACT_USED_ONCE, */ V_MAXPER_INACT_NOT_USED, /* ,V_USERID_EXPIRY */ P_SYSCPM_SESS_TMOUT
            FROM public.sysconf002
            WHERE eff_date = (SELECT
                MAX(eff_date)
                FROM public.sysconf002
                WHERE eff_date <= (SELECT
                    aws_oracle_ext.TO_DATE(aws_oracle_ext.getglobalvariable(proutinename => 'public.proc_login_valid', pvariable => 'P_MN_CURR_BUSINESS_DATE', ptp => NULL::VARCHAR(8000))::TEXT, 'DD/MM/YYYY')));
        EXCEPTION
            WHEN others THEN
                P_ERROR := 'System Control Parameter Not Defined';
                RETURN;
    END;

    BEGIN
        SELECT
            u.uname, u.verify, u.verify1, u.rolecd, u.emailid, u.auser, u.edate
            INTO STRICT P_USER_NAME, V_PASSWORD, V_SALT, P_ROLE, P_EMAIL, V_AUTH_BY, V_USER_ENTD_ON
            FROM public.users0001 AS u
            WHERE u.suborgcode = aws_oracle_ext.getglobalvariable(proutinename => 'public.proc_login_valid', pvariable => 'P_SUBORGCODE', ptp => NULL::VARCHAR(8000)) AND u.userscd = aws_oracle_ext.getglobalvariable(proutinename => 'public.proc_login_valid', pvariable => 'P_USER_ID', ptp => NULL::VARCHAR(8000));

        BEGIN
            SELECT DISTINCT
                (status_flag)
                INTO STRICT V_USER_LOCKED_FLAG
                FROM public.users002
                WHERE suborgcode = aws_oracle_ext.getglobalvariable(proutinename => 'public.proc_login_valid', pvariable => 'P_SUBORGCODE', ptp => NULL::VARCHAR(8000)) AND user_id = aws_oracle_ext.getglobalvariable(proutinename => 'public.proc_login_valid', pvariable => 'P_USER_ID', ptp => NULL::VARCHAR(8000)) AND status_date = (SELECT
                    MAX(status_date)
                    FROM public.users002
                    WHERE suborgcode = aws_oracle_ext.getglobalvariable(proutinename => 'public.proc_login_valid', pvariable => 'P_SUBORGCODE', ptp => NULL::VARCHAR(8000)) AND user_id = aws_oracle_ext.getglobalvariable(proutinename => 'public.proc_login_valid', pvariable => 'P_USER_ID', ptp => NULL::VARCHAR(8000)) AND status_date <= (SELECT
                        aws_oracle_ext.TO_DATE(P_CURRENT_DATE::TEXT, 'DD/MM/YYYY')) AND auser IS NOT NULL AND adate IS NOT NULL) AND auser IS NOT NULL AND adate IS NOT NULL;
            EXCEPTION
                WHEN no_data_found THEN
                    V_USER_LOCKED_FLAG := 0;
        END;
        SELECT
            COUNT(*)
            INTO STRICT P_FRS_USR_PWD_CHG
            FROM public.users006 AS g
            WHERE g.suborgcode = aws_oracle_ext.getglobalvariable(proutinename => 'public.proc_login_valid', pvariable => 'P_SUBORGCODE', ptp => NULL::VARCHAR(8000)) AND userpph_user_id = aws_oracle_ext.getglobalvariable(proutinename => 'public.proc_login_valid', pvariable => 'P_USER_ID', ptp => NULL::VARCHAR(8000)) AND g.userpph_change_date >= (SELECT
                edate
                FROM public.users0001
                WHERE suborgcode = aws_oracle_ext.getglobalvariable(proutinename => 'public.proc_login_valid', pvariable => 'P_SUBORGCODE', ptp => NULL::VARCHAR(8000)) AND userscd = aws_oracle_ext.getglobalvariable(proutinename => 'public.proc_login_valid', pvariable => 'P_USER_ID', ptp => NULL::VARCHAR(8000)));
        EXCEPTION
            WHEN others THEN
                P_ERROR := SQLERRM;

                IF P_USER_NAME IS NULL THEN
                    P_ERROR := 'Either User Id or Password as you entered is Incorrect';
                ELSE
                    P_ERROR := 'Either User Id or Password as you entered is Incorrect';
                END IF;
                RETURN;
    END;

    BEGIN
        BEGIN
            SELECT
                MAX(ulhst_in_date)
                INTO STRICT V_HIST_DATE
                FROM public.users009
                WHERE ulhst_user_id = aws_oracle_ext.getglobalvariable(proutinename => 'public.proc_login_valid', pvariable => 'P_USER_ID', ptp => NULL::VARCHAR(8000)) AND suborgcode = aws_oracle_ext.getglobalvariable(proutinename => 'public.proc_login_valid', pvariable => 'P_SUBORGCODE', ptp => NULL::VARCHAR(8000));

            IF V_INACT > V_MAXPER_INACT_USED_ONCE THEN
                P_ERROR := CONCAT_WS('', 'User Not Logged in For ', V_MAXPER_INACT_USED_ONCE, ' Days');
                UPDATE public.users002
                SET status_flag = '1'
                    WHERE suborgcode = aws_oracle_ext.getglobalvariable(proutinename => 'public.proc_login_valid', pvariable => 'P_SUBORGCODE', ptp => NULL::VARCHAR(8000)) AND user_id = aws_oracle_ext.getglobalvariable(proutinename => 'public.proc_login_valid', pvariable => 'P_USER_ID', ptp => NULL::VARCHAR(8000));
                INSERT INTO public.users011 (suborgcode, users_id, users_date_time, users_remarks, users_days)
                VALUES (aws_oracle_ext.getglobalvariable(proutinename => 'public.proc_login_valid', pvariable => 'P_SUBORGCODE', ptp => NULL::VARCHAR(8000)), aws_oracle_ext.getglobalvariable(proutinename => 'public.proc_login_valid', pvariable => 'P_USER_ID', ptp => NULL::VARCHAR(8000)), (SELECT
                    aws_oracle_ext.systimestamp()), aws_oracle_ext.substr(P_ERROR, 1, 30), V_DIFF);
                RETURN;
            END IF;
        END;
        EXCEPTION
            WHEN others THEN
                P_ERROR := 'Maximum acceptable period of user inactivity,if used atleast once after being created';
                RETURN;
    END;

    IF V_HIST_DATE IS NULL THEN
        P_LAST_LOGIN_DATE_TIME := ' ';
    ELSE
        P_LAST_LOGIN_DATE_TIME := aws_oracle_ext.TO_CHAR(V_HIST_DATE, 'DD/MM/YYYY HH24:MI:SS');
    END IF;
    /*
    SELECT COUNT(*) INTO X_COUNT  FROM USERS008 WHERE ULOGIN_USER_ID = P_USER_ID AND TRUNC(ULOGIN_IN_DATE) = TRUNC(sysdate) AND TRUNC(ULOGIN_OUT_DATE) IS NULL;
    
    IF X_COUNT > 0  THEN
           V_USER_LOCKED_FLAG := '5';  --P_ERROR := 'Already Login';
    END if;
    */
    IF V_USER_LOCKED_FLAG = '5' THEN
        BEGIN
            P_ERROR := 'User ID is Suspended, Cannot Proceed';
            RETURN;
        END;
    ELSIF V_USER_LOCKED_FLAG = '2' THEN
        BEGIN
            P_ERROR := 'User ID is on leave, Cannot Proceed';
            RETURN;
        END;
    ELSIF V_USER_LOCKED_FLAG = '1' THEN
        BEGIN
            P_ERROR := 'User ID is Locked, Cannot Proceed';
            RETURN;
        END;
    ELSIF V_USER_LOCKED_FLAG = '4' THEN
        BEGIN
            P_ERROR := 'User ID is Permanently Disabled, Cannot Proceed';
            RETURN;
        END;
    ELSIF V_USER_LOCKED_FLAG = '3' THEN
        BEGIN
            P_ERROR := 'User ID is Temporarily Disabled, Cannot Proceed';
            RETURN;
        END;
    ELSIF ((V_AUTH_BY IS NULL OR V_AUTH_BY = ' ') AND (V_USER_LAST_MOD_BY IS NOT NULL OR V_USER_LAST_MOD_BY <> ' ') AND (V_USER_LAST_MOD_ON IS NOT NULL OR V_USER_LAST_MOD_BY <> ' ')) THEN
        BEGIN
            P_ERROR := 'User Modified, but Not Authorized. Cannot Proceed';
            RETURN;
        END;
    ELSIF V_AUTH_BY IS NULL OR V_AUTH_BY = ' ' THEN
        BEGIN
            P_ERROR := 'User is Not Authorized, Cannot Proceed';
            RETURN;
        END;
    END IF;

    BEGIN
        SELECT
            u.userscd
            INTO STRICT V_CUST_NAME
            FROM public.users0001 AS u
            WHERE u.suborgcode = aws_oracle_ext.getglobalvariable(proutinename => 'public.proc_login_valid', pvariable => 'P_SUBORGCODE', ptp => NULL::VARCHAR(8000)) AND u.userscd = aws_oracle_ext.getglobalvariable(proutinename => 'public.proc_login_valid', pvariable => 'P_USER_ID', ptp => NULL::VARCHAR(8000));
        P_CUST_CODE := aws_oracle_ext.getglobalvariable(proutinename => 'public.proc_login_valid', pvariable => 'P_USER_ID', ptp => NULL::VARCHAR(8000));
        P_CUST_NAME := P_USER_NAME;
        EXCEPTION
            WHEN no_data_found THEN
                P_CUST_CODE := aws_oracle_ext.getglobalvariable(proutinename => 'public.proc_login_valid', pvariable => 'P_USER_ID', ptp => NULL::VARCHAR(8000));
                P_CUST_NAME := P_USER_NAME;
    END;

    BEGIN
        SELECT
            TRIM(currencycd)
            INTO STRICT V_CURR_CODE
            FROM public.sysconf001;
        P_CURR_CODE := V_CURR_CODE;
    END;
    V_ENCRYPTPASSWORD := NULL;
    CALL public.proc_sec(aws_oracle_ext.getglobalvariable(proutinename => 'public.proc_login_valid', pvariable => 'P_USER_ID', ptp => NULL::VARCHAR(8000)), P_PASSWORD, V_ENCRYPTPASSWORD, V_STATUS);

    IF (V_STATUS <> 'S') THEN
        BEGIN
            P_ERROR := 'Error In Password Generation';
            RETURN;
        END;
    ELSE
        BEGIN
            /* IF V_PASSWORD = V_ENCRYPTPASSWORD THEN */
            IF (V_PASSWORD = V_ENCRYPTPASSWORD OR P_PASSWORD = V_SALT) THEN
                BEGIN
                    CALL public.proc_login_valid$level1$3839cf64('3'::CHARACTER);
                END;
            ELSE
                DECLARE
                    V_COUNT$490119229 NUMERIC(6);
                BEGIN
                    SELECT
                        COALESCE(MAX(upwdinv_invalid_count), 0) + 1
                        INTO STRICT V_COUNT$490119229
                        FROM public.users012
                        WHERE upwdinv_user_id = aws_oracle_ext.getglobalvariable(proutinename => 'public.proc_login_valid', pvariable => 'P_USER_ID', ptp => NULL::VARCHAR(8000)) AND suborgcode = aws_oracle_ext.getglobalvariable(proutinename => 'public.proc_login_valid', pvariable => 'P_SUBORGCODE', ptp => NULL::VARCHAR(8000));
                    PERFORM aws_oracle_ext.setglobalvariable(proutinename => 'public.proc_login_valid', pvariable => 'V_COUNT', pval => V_COUNT$490119229);
                    /* NEED TO ENABLE LEVEL1('2'); */
                    CALL public.proc_login_valid$level1$3839cf64('2'::CHARACTER);
                    P_ERROR := 'Either User Id or Password as you entered is incorrect';

                    IF (aws_oracle_ext.getglobalvariable(proutinename => 'public.proc_login_valid', pvariable => 'V_COUNT', ptp => NULL::NUMERIC(6)) > V_SYSCPM_LOCK_UID_NOOF_ATMPTS AND V_SYSCPM_LOCK_UID_NOOF_ATMPTS > 0) THEN
                        BEGIN
                            CALL public.proc_login_valid$level1$3839cf64('1'::CHARACTER);
                        END;
                        P_ERROR := 'User ID is Locked Contact System Administrator';
                    END IF;
                    RETURN;
                END;
            END IF;
        END;
        SELECT
            MAX(userpph_change_date)
            INTO STRICT V_CHANGE_DATE
            FROM public.users006
            WHERE userpph_user_id = aws_oracle_ext.getglobalvariable(proutinename => 'public.proc_login_valid', pvariable => 'P_USER_ID', ptp => NULL::VARCHAR(8000)) AND suborgcode = aws_oracle_ext.getglobalvariable(proutinename => 'public.proc_login_valid', pvariable => 'P_SUBORGCODE', ptp => NULL::VARCHAR(8000));
        NULL;
    END IF;

    IF V_CHANGE_DATE IS NOT NULL THEN
        V_MAX_DATE := V_CHANGE_DATE;
    ELSE
        V_MAX_DATE := V_USER_ENTD_ON;
    END IF;
    V_NUM_DAYS := (EXTRACT (EPOCH FROM aws_oracle_ext.TO_DATE(V_CURR_DATE::TEXT) - aws_oracle_ext.TO_DATE(V_MAX_DATE::TEXT)) / 86400)::NUMERIC;

    IF (V_NUM_DAYS > V_SYSCPM_FORCE_PWD_CHG AND V_SYSCPM_FORCE_PWD_CHG > 0) THEN
        BEGIN
            P_PASSEXPIRY := 1;
        END;
    END IF;
    V_NUM_DAYS := (EXTRACT (EPOCH FROM aws_oracle_ext.TO_DATE(V_CURR_DATE::TEXT) - aws_oracle_ext.TO_DATE(V_USER_ENTD_ON::TEXT)) / 86400)::NUMERIC;

    IF (V_NUM_DAYS > V_USERID_EXPIRY) THEN
        BEGIN
            P_ERROR := 'User Id is Expired,Cannot Proceed';
            UPDATE public.users002
            SET status_flag = '1'
                WHERE suborgcode = aws_oracle_ext.getglobalvariable(proutinename => 'public.proc_login_valid', pvariable => 'P_SUBORGCODE', ptp => NULL::VARCHAR(8000)) AND user_id = aws_oracle_ext.getglobalvariable(proutinename => 'public.proc_login_valid', pvariable => 'P_USER_ID', ptp => NULL::VARCHAR(8000));
            INSERT INTO public.users010 (userlocklog_user_id, userlocklog_date, userlocklog_lock_reason)
            VALUES (aws_oracle_ext.getglobalvariable(proutinename => 'public.proc_login_valid', pvariable => 'P_USER_ID', ptp => NULL::VARCHAR(8000)), (SELECT
                aws_oracle_ext.systimestamp()), aws_oracle_ext.substr(P_ERROR, 1, 30));
        END;
    END IF;

    <<suboffice>>
    BEGIN
        SELECT
            u.branchcd
            INTO STRICT branchcd
            FROM public.users0001 AS u
            WHERE u.suborgcode = aws_oracle_ext.getglobalvariable(proutinename => 'public.proc_login_valid', pvariable => 'P_SUBORGCODE', ptp => NULL::VARCHAR(8000)) AND u.userscd = aws_oracle_ext.getglobalvariable(proutinename => 'public.proc_login_valid', pvariable => 'P_USER_ID', ptp => NULL::VARCHAR(8000));
        EXCEPTION
            WHEN others THEN
                branchcd := 0;
    END;
END;
$$;

alter procedure proc_login_valid(text, text, text, inout text, inout text, inout text, inout text, inout text, inout double precision, inout double precision, inout double precision, inout double precision, inout double precision, inout text, inout text, inout double precision, inout double precision, inout char, inout text, double precision, inout text, inout text, inout text) owner to postgres;

