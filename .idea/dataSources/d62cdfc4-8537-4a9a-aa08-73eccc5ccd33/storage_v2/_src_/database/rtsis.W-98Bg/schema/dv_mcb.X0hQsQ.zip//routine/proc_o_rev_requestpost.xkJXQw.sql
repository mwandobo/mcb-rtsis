create function proc_o_rev_requestpost(i_suborg text, i_initiateby text, i_paytype text, i_reqdate text, i_reqrefno text, i_reqsl text, i_servcd text, OUT o_status text, OUT o_rescd text, OUT o_resdesc text, OUT o_payload text, OUT o_signpayload text, OUT o_headerid text, OUT o_method text, OUT o_uri text, OUT o_format text, OUT o_protocol text, OUT o_flow text, OUT o_tranamount text, OUT o_dbcurr text, OUT o_chrgamount text, OUT o_chrgcurr text, OUT o_dbaccount text, OUT o_craccount text, OUT o_chrgaccount text, OUT o_narration text, OUT o_reqcode text, OUT o_brncode text, OUT o_channel text, OUT o_result text, OUT o_message text) returns record
    language plpgsql
as
$$
DECLARE
    v_debitcurr CHARACTER VARYING(10) := NULL;
    v_debibrn CHARACTER VARYING(50) := NULL;
    v_creditcurr CHARACTER VARYING(10) := NULL;
    v_creditbrn CHARACTER VARYING(50) := NULL;
    v_chrg_account CHARACTER VARYING(50) := NULL;
    v_tranamnt CHARACTER VARYING(50) := NULL;
    v_chrgamnt CHARACTER VARYING(50) := NULL;
    V_REVERSE_REASON CHARACTER VARYING(250) := NULL;
    V_REJECT_REASON CHARACTER VARYING(250) := NULL;
    V_REVERSE_REF CHARACTER VARYING(50) := NULL;
    V_APPROVAL CHARACTER VARYING(50) := NULL;
    v_payerref CHARACTER VARYING(70) := NULL;
    v_destac CHARACTER VARYING(70) := NULL;
    v_payer_Name CHARACTER VARYING(250) := NULL;
    v_payee_Name CHARACTER VARYING(250) := NULL;
    V_COUNT NUMERIC(10) := 0;
	v_error_stack CHARACTER VARYING(250) := NULL;
    loop1 RECORD;
BEGIN
    /* ************************************************** TIPS *************************************************** */
    IF (I_PAYTYPE = 'TIPS') THEN
        IF (I_INITIATEBY = 'TIPS') THEN /* ** Rev Req from Tips ** */
            IF (I_SERVCD = '2120') THEN /* **  Tips has initiated the Hold Request to ABSA and we have to Proceed Hold cbs posting ** */
                <<EXCEP>>
                BEGIN
                    SELECT
                        j.reason, j.rev_ref
                        INTO STRICT V_REVERSE_REASON, V_REVERSE_REF
                        FROM  job005 AS j
                        WHERE j.suborgcode = I_SUBORG AND j.syscode = 'HP' AND j.paytype = I_PAYTYPE AND j.reqdate = I_REQDATE::TIMESTAMP WITHOUT TIME ZONE AND j.refno = I_REQREFNO AND j.reqsl = I_REQSL;

                    FOR loop1 IN
                    SELECT
                        *
                        FROM  pay001 AS r
                        WHERE r.suborgcode = I_SUBORG AND r.paytype = I_PAYTYPE AND r.tranrefno = I_REQREFNO AND r.reqsl = I_REQSL
                    LOOP
                        INSERT INTO  pay002 (suborgcode, chcode, paytype, reqdate, reqrefno, tranrefno, reqsl, reqtime, paydate, trantype, initiateby, org_amnt, org_curr, org_chrgamnt, org_chrgcurr, org_refno, rev_amount, rev_curr, rev_chrgamount, rev_chrgcurr, rev_refno, rev_type, isfinal_rev, rev_code, rev_reason, hold_state, hold_amount, hold_curr, payerid, payeeid, tran_switchref, rev_switchref, rev_status, payer_revref, payee_revref, isholdapproved, isrevapproved, holdrejreason, revrejreason)
                        VALUES (loop1.suborgcode, loop1.chcode, loop1.paytype, loop1.reqdate, loop1.reqrefno, loop1.tranrefno, loop1.reqsl, loop1.reqtime, loop1.paydate, loop1.trantype, 'TIPS', loop1.tranamt, loop1.trancurr, loop1.feeamt1, loop1.feecurr1, loop1.tranrefno, loop1.tranamt, loop1.trancurr, loop1.feeamt1, loop1.feecurr1, NULL, 'F', 0, NULL, V_REVERSE_REASON, 'REQUESTED', loop1.tranamt, loop1.trancurr, loop1.payerid, loop1.payeeref, loop1.switchref, NULL, NULL, V_REVERSE_REF, NULL, 1, 0, NULL, NULL);
                        O_DBACCOUNT := loop1.d_account; /* ** ABSA customer account * */
                        v_debibrn := loop1.d_brncode;
                        O_FLOW := loop1.flow;
                        v_payerref := loop1.payerid;
                        v_destac := loop1.d_account;
                        v_payer_Name := loop1.d_acname;
                    END LOOP;
                    SELECT
                        w.payload, w.signpayload, w.headerid, w.method, w.uri, w.format, w.protocol
                        INTO STRICT O_PAYLOAD, O_SIGNPAYLOAD, O_HEADERID, O_METHOD, O_URI, O_FORMAT, O_PROTOCOL
                        FROM  webservice001 AS w
                        WHERE w.suborgcode = I_SUBORG AND w.syscode = 'HP' AND w.chcode = I_PAYTYPE AND w.servicecd = I_SERVCD AND w.flow = 'O';

                    FOR loop1 IN
                    SELECT
                        *
                        FROM  pay002 AS r
                        WHERE r.suborgcode = I_SUBORG AND r.paytype = I_PAYTYPE AND r.reqsl = I_REQSL
                    LOOP
                        O_PAYLOAD := replace(O_PAYLOAD, '~payerReversalRef~', coalesce(loop1.payer_revref, ''));
                        O_PAYLOAD := replace(O_PAYLOAD, '~payerRef~', coalesce(loop1.payerid, ''));
                        O_PAYLOAD := replace(O_PAYLOAD, '~payeeRef~', coalesce(loop1.payeeid, ''));
                        O_PAYLOAD := replace(O_PAYLOAD, '~switchRef~', coalesce(loop1.tran_switchref, ''));
                        O_PAYLOAD := replace(O_PAYLOAD, '~amount~', coalesce(loop1.org_amnt::TEXT, ''));
                        O_PAYLOAD := replace(O_PAYLOAD, '~currency~', coalesce(loop1.org_curr, ''));
                        O_PAYLOAD := replace(O_PAYLOAD, '~reversalReason~', coalesce(loop1.rev_reason, ''));
                        O_TRANAMOUNT := loop1.org_amnt::TEXT;
                        O_CHRGAMOUNT := loop1.rev_chrgamount::TEXT;
                        O_CHRGCURR := loop1.rev_chrgcurr;
                        v_debitcurr := loop1.org_curr;
                        v_creditcurr := loop1.org_curr;
                        O_CHANNEL := loop1.chcode;
                    /* v_payer_Name := loop1. */
                    END LOOP;
                    /* ** CBS Account Mapping (Note : Debit/source Ac : ABSA Customer Account 0/Destination Ac : Tips Rev Ac) * */
                    v_tranamnt := O_TRANAMOUNT;
                    O_DBCURR := 'TZS';
                    O_CHRGAMOUNT := O_CHRGAMOUNT;
                    SELECT
                        crgl, acname
                        INTO STRICT O_CRACCOUNT, v_payee_Name
                        FROM  ledgermap
                        WHERE program = 'TIPS' AND trantype = 'R'; /* ** TIPS REVERSE Account * */

                    IF (O_CRACCOUNT IS NOT NULL AND LENGTH(O_CRACCOUNT) = 10) THEN
                        v_creditbrn := SUBSTRING(O_CRACCOUNT, 1, 3);
                        O_CRACCOUNT := SUBSTRING(O_CRACCOUNT, 4);
                    END IF;

                    IF (O_DBACCOUNT IS NOT NULL AND LENGTH(O_DBACCOUNT) = 10) THEN
                        v_debibrn := SUBSTRING(O_DBACCOUNT, 1, 3);
                        O_DBACCOUNT := SUBSTRING(O_DBACCOUNT, 4);
                    END IF;
                    /* O_NARRATION := 'TIPS: Identifier; ' || O_DBACCOUNT || ' CRAc; ' || O_CRACCOUNT; */
                    O_NARRATION := CONCAT_WS('', 'TIPS: DEST: ', v_destac, ' Payer Ref: ', v_payerref);
                    O_REQCODE := '-';
                    O_BRNCODE := CONCAT_WS('', v_debibrn, '|', v_debibrn, '|', v_creditbrn, '|');
                    V_COUNT := 0;
                    V_COUNT := V_COUNT + 1;
                    INSERT INTO  transactions (suborgcode, trantype, trancode, systemdate, transeq, legsl, branchcd, trandate, chcode, chrefno, dbcr, amount, trancurr, sysamount, syscurr, accountno, iban, swiftcd, ledgerno, paytype, charges, chgcode, remarks, euser, edate, auser, adate, cuser, cdate, status, invoiceno, syscode, paysl, addinfo2, addinfo3)
                    VALUES (I_SUBORG, 'TRANSFER', 'TD', (CLOCK_TIMESTAMP() AT TIME ZONE COALESCE(CURRENT_SETTING('aws_oracle_ext.tz', TRUE), 'UTC'))::TIMESTAMP(0), V_COUNT, 1, v_debibrn, I_REQDATE, O_CHANNEL, I_REQREFNO, 'D', v_tranamnt, v_debitcurr, O_TRANAMOUNT, v_debitcurr, O_DBACCOUNT, NULL, NULL, NULL, I_PAYTYPE, NULL, NULL, O_NARRATION, I_INITIATEBY, (CLOCK_TIMESTAMP() AT TIME ZONE COALESCE(CURRENT_SETTING('aws_oracle_ext.tz', TRUE), 'UTC'))::TIMESTAMP(0), I_INITIATEBY, (CLOCK_TIMESTAMP() AT TIME ZONE COALESCE(CURRENT_SETTING('aws_oracle_ext.tz', TRUE), 'UTC'))::TIMESTAMP(0), NULL, NULL, 'PENDING', NULL, 'HP', I_REQSL, v_payer_Name, v_payee_Name);
                    INSERT INTO  transactions (suborgcode, trantype, trancode, systemdate, transeq, legsl, branchcd, trandate, chcode, chrefno, dbcr, amount, trancurr, sysamount, syscurr, accountno, iban, swiftcd, ledgerno, paytype, charges, chgcode, remarks, euser, edate, auser, adate, cuser, cdate, status, invoiceno, syscode, paysl, addinfo2, addinfo3)
                    VALUES (I_SUBORG, 'TRANSFER', 'TC', (CLOCK_TIMESTAMP() AT TIME ZONE COALESCE(CURRENT_SETTING('aws_oracle_ext.tz', TRUE), 'UTC'))::TIMESTAMP(0), V_COUNT, 2, v_creditbrn, I_REQDATE, O_CHANNEL, I_REQREFNO, 'C', v_tranamnt, v_debitcurr, O_TRANAMOUNT, v_debitcurr, NULL, NULL, NULL, O_CRACCOUNT, I_PAYTYPE, NULL, NULL, O_NARRATION, I_INITIATEBY, (CLOCK_TIMESTAMP() AT TIME ZONE COALESCE(CURRENT_SETTING('aws_oracle_ext.tz', TRUE), 'UTC'))::TIMESTAMP(0), I_INITIATEBY, (CLOCK_TIMESTAMP() AT TIME ZONE COALESCE(CURRENT_SETTING('aws_oracle_ext.tz', TRUE), 'UTC'))::TIMESTAMP(0), NULL, NULL, 'PENDING', NULL, 'HP', I_REQSL, v_payer_Name, v_payee_Name);
                    O_RESULT := 'S';
                    EXCEPTION
                        WHEN others THEN
						GET STACKED DIAGNOSTICS v_error_stack = PG_EXCEPTION_CONTEXT;
              raise '% : %', sqlstate, sqlerrm;
                           
                            O_RESULT := 'F';
                END;
            END IF;

            IF (I_SERVCD = '2120C') THEN /* **  Cancel the Hold Request ** */
                <<EXCEP>>
                BEGIN
                    SELECT
                        w.payload, w.signpayload, w.headerid, w.method, w.uri, w.format, w.protocol
                        INTO STRICT O_PAYLOAD, O_SIGNPAYLOAD, O_HEADERID, O_METHOD, O_URI, O_FORMAT, O_PROTOCOL
                        FROM  webservice001 AS w
                        WHERE w.suborgcode = I_SUBORG AND w.syscode = 'HP' AND w.chcode = I_PAYTYPE AND w.servicecd = '2120' AND w.flow = 'O';
                    UPDATE  pay002
                    SET hold_state = 'CANCELLED'
                        WHERE paytype = I_PAYTYPE AND reqrefno = I_REQREFNO AND reqsl = I_REQSL;

                    FOR loop1 IN
                    SELECT
                        *
                        FROM  pay001 AS r
                        WHERE r.suborgcode = I_SUBORG AND r.paytype = I_PAYTYPE AND r.tranrefno = I_REQREFNO AND r.reqsl = I_REQSL
                    LOOP
                        O_CRACCOUNT := loop1.d_account; /* ** ABSA customer account * */
                        v_creditbrn := loop1.d_brncode;
                        O_FLOW := loop1.flow;
                        v_payerref := loop1.payerid;
                        v_destac := loop1.d_account;
                        v_payee_Name := loop1.d_acname;
                    END LOOP;

                    FOR loop1 IN
                    SELECT
                        *
                        FROM  pay002 AS r
                        WHERE r.suborgcode = I_SUBORG AND r.paytype = I_PAYTYPE AND r.reqsl = I_REQSL
                    LOOP
                        O_PAYLOAD := replace(O_PAYLOAD, '~payerReversalRef~', coalesce(loop1.payer_revref, ''));
                        O_PAYLOAD := replace(O_PAYLOAD, '~payerRef~', coalesce(loop1.payerid, ''));
                        O_PAYLOAD := replace(O_PAYLOAD, '~payeeRef~', coalesce(loop1.payeeid, ''));
                        O_PAYLOAD := replace(O_PAYLOAD, '~switchRef~', coalesce(loop1.tran_switchref, ''));
                        O_PAYLOAD := replace(O_PAYLOAD, '~amount~', coalesce(loop1.org_amnt::TEXT, ''));
                        O_PAYLOAD := replace(O_PAYLOAD, '~currency~', coalesce(loop1.org_curr, ''));
                        O_PAYLOAD := replace(O_PAYLOAD, '~reversalReason~', coalesce(loop1.rev_reason, ''));
                        /* O_PAYLOAD :=  replace(O_PAYLOAD, '~reversalState~', 'CANCELLED'); */
                        /* O_PAYLOAD :=  replace(O_PAYLOAD, '~reversalReason~', loop1.REV_REASON); */
                        O_TRANAMOUNT := loop1.org_amnt::TEXT;
                        O_CHRGAMOUNT := loop1.rev_chrgamount::TEXT;
                        O_CHRGCURR := loop1.rev_chrgcurr;
                        v_debitcurr := loop1.org_curr;
                        v_creditcurr := loop1.org_curr;
                        O_CHANNEL := loop1.chcode;
                    END LOOP;
                    /* ** CBS Account Mapping (Note : Debit/source Ac : Tips Rev Ac 00/Destination Ac : ABSA Customer Account) * */
                    /* v_debibrn := v_creditbrn; */
                    v_tranamnt := O_TRANAMOUNT;
                    O_DBCURR := 'TZS';
                    SELECT
                        crgl, acname
                        INTO STRICT O_DBACCOUNT, v_payer_Name
                        FROM  ledgermap
                        WHERE program = 'TIPS' AND trantype = 'R'; /* ** TIPS REVERSE Account * */

                    IF (O_CRACCOUNT IS NOT NULL AND LENGTH(O_CRACCOUNT) = 10) THEN
                        v_creditbrn := SUBSTRING(O_CRACCOUNT, 1, 3);
                        O_CRACCOUNT := SUBSTRING(O_CRACCOUNT, 4);
                    END IF;

                    IF (O_DBACCOUNT IS NOT NULL AND LENGTH(O_DBACCOUNT) = 10) THEN
                        v_debibrn := SUBSTRING(O_DBACCOUNT, 1, 3);
                        O_DBACCOUNT := SUBSTRING(O_DBACCOUNT, 4);
                    END IF;
                    /* O_NARRATION := 'TIPS: Identifier; ' || O_DBACCOUNT || ' CRAc; ' || O_CRACCOUNT; */
                    O_NARRATION := CONCAT_WS('', 'TIPS: DEST: ', v_destac, ' Payer Ref: ', v_payerref);
                    O_REQCODE := 'TZS';
                    O_BRNCODE := CONCAT_WS('', v_debibrn, '|', v_debibrn, '|', v_creditbrn, '|');
                    V_COUNT := 0;
                    V_COUNT := V_COUNT + 1;
                    INSERT INTO  transactions (suborgcode, trantype, trancode, systemdate, transeq, legsl, branchcd, trandate, chcode, chrefno, dbcr, amount, trancurr, sysamount, syscurr, accountno, iban, swiftcd, ledgerno, paytype, charges, chgcode, remarks, euser, edate, auser, adate, cuser, cdate, status, invoiceno, syscode, paysl, addinfo2, addinfo3)
                    VALUES (I_SUBORG, 'TRANSFER', 'TD', (CLOCK_TIMESTAMP() AT TIME ZONE COALESCE(CURRENT_SETTING('aws_oracle_ext.tz', TRUE), 'UTC'))::TIMESTAMP(0), V_COUNT, 1, v_debibrn, I_REQDATE, O_CHANNEL, I_REQREFNO, 'D', v_tranamnt, v_debitcurr, O_TRANAMOUNT, v_debitcurr, O_DBACCOUNT, NULL, NULL, NULL, I_PAYTYPE, NULL, NULL, O_NARRATION, I_INITIATEBY, (CLOCK_TIMESTAMP() AT TIME ZONE COALESCE(CURRENT_SETTING('aws_oracle_ext.tz', TRUE), 'UTC'))::TIMESTAMP(0), I_INITIATEBY, (CLOCK_TIMESTAMP() AT TIME ZONE COALESCE(CURRENT_SETTING('aws_oracle_ext.tz', TRUE), 'UTC'))::TIMESTAMP(0), NULL, NULL, 'PENDING', NULL, 'HP', I_REQSL, v_payer_Name, v_payee_Name);
                    INSERT INTO  transactions (suborgcode, trantype, trancode, systemdate, transeq, legsl, branchcd, trandate, chcode, chrefno, dbcr, amount, trancurr, sysamount, syscurr, accountno, iban, swiftcd, ledgerno, paytype, charges, chgcode, remarks, euser, edate, auser, adate, cuser, cdate, status, invoiceno, syscode, paysl, addinfo2, addinfo3)
                    VALUES (I_SUBORG, 'TRANSFER', 'TC', (CLOCK_TIMESTAMP() AT TIME ZONE COALESCE(CURRENT_SETTING('aws_oracle_ext.tz', TRUE), 'UTC'))::TIMESTAMP(0), V_COUNT, 2, v_creditbrn, I_REQDATE, O_CHANNEL, I_REQREFNO, 'C', v_tranamnt, v_debitcurr, O_TRANAMOUNT, v_debitcurr, NULL, NULL, NULL, O_CRACCOUNT, I_PAYTYPE, NULL, NULL, O_NARRATION, I_INITIATEBY, (CLOCK_TIMESTAMP() AT TIME ZONE COALESCE(CURRENT_SETTING('aws_oracle_ext.tz', TRUE), 'UTC'))::TIMESTAMP(0), I_INITIATEBY, (CLOCK_TIMESTAMP() AT TIME ZONE COALESCE(CURRENT_SETTING('aws_oracle_ext.tz', TRUE), 'UTC'))::TIMESTAMP(0), NULL, NULL, 'PENDING', NULL, 'HP', I_REQSL, v_payer_Name, v_payee_Name);
                    O_RESULT := 'S';
                    EXCEPTION
                        WHEN others THEN
						GET STACKED DIAGNOSTICS v_error_stack = PG_EXCEPTION_CONTEXT;
                      raise '% : %', sqlstate, sqlerrm;
                            O_RESULT := 'F';
                END;
            END IF;

            IF (I_SERVCD = '2122') THEN /* * approval for Initiate Reversal cbs posting  * */
                <<EXCEP>>
                BEGIN
                    SELECT
                        r.chcode, r.d_brncode, r.flow, r.tranamt, r.trancurr, r.payerid, r.d_account
                        INTO STRICT O_CHANNEL, v_debibrn, O_FLOW, O_TRANAMOUNT, v_debitcurr, v_payerref, v_destac
                        FROM  pay001 AS r
                        WHERE r.suborgcode = I_SUBORG AND r.paytype = I_PAYTYPE AND r.reqsl = I_REQSL;
                    /* ** CBS Account Mapping (Note : Debit/source Ac : TIPS REVERSE Account 10/Destination Ac : TIPS Inward Collection Account) * */
                    v_creditcurr := v_debitcurr;
                    v_creditbrn := v_debibrn;
                    v_tranamnt := O_TRANAMOUNT;
                    O_DBCURR := 'TZS';
                    SELECT
                        crgl, acname
                        INTO STRICT O_DBACCOUNT, v_payer_Name
                        FROM  ledgermap
                        WHERE program = 'TIPS' AND trantype = 'R'; /* ** TIPS REVERSE Account * */
                    SELECT
                        dbgl, acname
                        INTO STRICT O_CRACCOUNT, v_payee_Name
                        FROM  ledgermap
                        WHERE program = 'TIPS' AND usergroup = 'I' AND dcflg = 'D' AND trantype = 'T'; /* ** TIPS INWARD COLLECTION * */

                    IF (O_CRACCOUNT IS NOT NULL AND LENGTH(O_CRACCOUNT) = 10) THEN
                        v_creditbrn := SUBSTRING(O_CRACCOUNT, 1, 3);
                        O_CRACCOUNT := SUBSTRING(O_CRACCOUNT, 4);
                    END IF;

                    IF (O_DBACCOUNT IS NOT NULL AND LENGTH(O_DBACCOUNT) = 10) THEN
                        v_debibrn := SUBSTRING(O_DBACCOUNT, 1, 3);
                        O_DBACCOUNT := SUBSTRING(O_DBACCOUNT, 4);
                    END IF;
                    O_NARRATION := CONCAT_WS('', 'TIPS: DEST: ', v_destac, ' Payer Ref: ', v_payerref);
                    O_REQCODE := '-';
                    O_BRNCODE := CONCAT_WS('', v_debibrn, '|', v_debibrn, '|', v_creditbrn, '|');
                    V_COUNT := 0;
                    V_COUNT := V_COUNT + 1;
                    INSERT INTO  transactions (suborgcode, trantype, trancode, systemdate, transeq, legsl, branchcd, trandate, chcode, chrefno, dbcr, amount, trancurr, sysamount, syscurr, accountno, iban, swiftcd, ledgerno, paytype, charges, chgcode, remarks, euser, edate, auser, adate, cuser, cdate, status, invoiceno, syscode, paysl, addinfo2, addinfo3)
                    VALUES (I_SUBORG, 'TRANSFER', 'TD', (CLOCK_TIMESTAMP() AT TIME ZONE COALESCE(CURRENT_SETTING('aws_oracle_ext.tz', TRUE), 'UTC'))::TIMESTAMP(0), V_COUNT, 1, v_debibrn, I_REQDATE, O_CHANNEL, I_REQREFNO, 'D', v_tranamnt, v_debitcurr, O_TRANAMOUNT, v_debitcurr, NULL, NULL, NULL, O_DBACCOUNT, I_PAYTYPE, NULL, NULL, O_NARRATION, I_INITIATEBY, (CLOCK_TIMESTAMP() AT TIME ZONE COALESCE(CURRENT_SETTING('aws_oracle_ext.tz', TRUE), 'UTC'))::TIMESTAMP(0), I_INITIATEBY, (CLOCK_TIMESTAMP() AT TIME ZONE COALESCE(CURRENT_SETTING('aws_oracle_ext.tz', TRUE), 'UTC'))::TIMESTAMP(0), NULL, NULL, 'PENDING', NULL, 'HP', I_REQSL, v_payer_Name, v_payee_Name);
                    INSERT INTO  transactions (suborgcode, trantype, trancode, systemdate, transeq, legsl, branchcd, trandate, chcode, chrefno, dbcr, amount, trancurr, sysamount, syscurr, accountno, iban, swiftcd, ledgerno, paytype, charges, chgcode, remarks, euser, edate, auser, adate, cuser, cdate, status, invoiceno, syscode, paysl, addinfo2, addinfo3)
                    VALUES (I_SUBORG, 'TRANSFER', 'TC', (CLOCK_TIMESTAMP() AT TIME ZONE COALESCE(CURRENT_SETTING('aws_oracle_ext.tz', TRUE), 'UTC'))::TIMESTAMP(0), V_COUNT, 2, v_creditbrn, I_REQDATE, O_CHANNEL, I_REQREFNO, 'C', v_tranamnt, v_debitcurr, O_TRANAMOUNT, v_debitcurr, NULL, NULL, NULL, O_CRACCOUNT, I_PAYTYPE, NULL, NULL, O_NARRATION, I_INITIATEBY, (CLOCK_TIMESTAMP() AT TIME ZONE COALESCE(CURRENT_SETTING('aws_oracle_ext.tz', TRUE), 'UTC'))::TIMESTAMP(0), I_INITIATEBY, (CLOCK_TIMESTAMP() AT TIME ZONE COALESCE(CURRENT_SETTING('aws_oracle_ext.tz', TRUE), 'UTC'))::TIMESTAMP(0), NULL, NULL, 'PENDING', NULL, 'HP', I_REQSL, v_payer_Name, v_payee_Name);
                    O_RESULT := 'S';
                    EXCEPTION
                        WHEN others THEN
						GET STACKED DIAGNOSTICS v_error_stack = PG_EXCEPTION_CONTEXT;
                       raise '% : %', sqlstate, sqlerrm;
                            O_RESULT := 'F';
                END;
            END IF;

            IF (I_SERVCD = '2110') THEN
                <<EXCEP>>
                BEGIN
                    SELECT
                        w.payload, w.signpayload, w.headerid, w.method, w.uri, w.format, w.protocol
                        INTO STRICT O_PAYLOAD, O_SIGNPAYLOAD, O_HEADERID, O_METHOD, O_URI, O_FORMAT, O_PROTOCOL
                        FROM  webservice001 AS w
                        WHERE w.suborgcode = I_SUBORG AND w.syscode = 'HP' AND w.chcode = I_PAYTYPE AND w.servicecd = I_SERVCD AND w.flow = 'O';

                    FOR loop1 IN
                    SELECT
                        *
                        FROM  pay001 AS r
                        WHERE r.suborgcode = I_SUBORG AND r.paytype = I_PAYTYPE AND r.tranrefno = I_REQREFNO AND r.reqsl = I_REQSL
                    LOOP
                        O_FLOW := loop1.flow;
                        O_TRANAMOUNT := loop1.tranamt::TEXT;
                        O_CHRGAMOUNT := loop1.feeamt1::TEXT;
                        O_CHRGCURR := loop1.feecurr1;
                        v_debitcurr := loop1.trancurr;
                        v_creditcurr := loop1.trancurr;
                        O_CHANNEL := loop1.chcode;
                    END LOOP;
                    O_RESULT := 'S';
                    EXCEPTION
                        WHEN others THEN
						GET STACKED DIAGNOSTICS v_error_stack = PG_EXCEPTION_CONTEXT;
                        raise '% : %', sqlstate, sqlerrm;
                            O_RESULT := 'F';
                END;
            END IF;
        ELSIF (I_INITIATEBY = 'ABSAPAY') THEN /* ** Reversal Req from Internal ABSAPAY ** */
            <<EXCEP>>
            BEGIN
                SELECT
                    (CONCAT_WS('', '020', '-', 'R', replace(aws_oracle_ext.TO_CHAR((CLOCK_TIMESTAMP() AT TIME ZONE COALESCE(CURRENT_SETTING('aws_oracle_ext.tz', TRUE), 'UTC'))::TIMESTAMP(0), 'yyyy-mm-dd'), '-', ''), TRUNC(aws_oracle_ext.dbms_random$value(100000, 999999)), nextval(' ref_id')))
                    INTO STRICT V_REVERSE_REF;
                V_REVERSE_REASON := 'INTERNAL SYSTEM ISSUE.';

                FOR loop1 IN
                SELECT
                    *
                    FROM  pay001 AS r
                    WHERE r.suborgcode = I_SUBORG AND r.paytype = I_PAYTYPE AND r.reqrefno = I_REQREFNO AND r.reqsl = I_REQSL
                LOOP
                    O_TRANAMOUNT := loop1.tranamt::TEXT;
                    O_CHRGAMOUNT := loop1.feeamt1::TEXT;
                    O_CHRGCURR := loop1.feecurr1;
                    O_CRACCOUNT := loop1.s_account; /* ** ABSA customer account * */
                    v_debitcurr := loop1.trancurr;
                    v_creditcurr := loop1.trancurr;
                    v_creditbrn := loop1.s_brncode;
                    O_CHANNEL := loop1.chcode;
                    O_BRNCODE := '';
                    O_NARRATION := CONCAT_WS('', 'Reversal: ', loop1.payerid);
                    INSERT INTO  pay002 (suborgcode, chcode, paytype, reqdate, reqrefno, tranrefno, reqsl, reqtime, paydate, trantype, initiateby, org_amnt, org_curr, org_chrgamnt, org_chrgcurr, org_refno, rev_amount, rev_curr, rev_chrgamount, rev_chrgcurr, rev_refno, rev_type, isfinal_rev, rev_code, rev_reason, payerid, payeeid, tran_switchref, rev_switchref, rev_status, payer_revref, payee_revref)
                    VALUES (loop1.suborgcode, loop1.chcode, loop1.paytype, loop1.reqdate, loop1.reqrefno, loop1.tranrefno, loop1.reqsl, loop1.reqtime, loop1.paydate, loop1.trantype, 'TIPS', loop1.tranamt, loop1.trancurr, loop1.feeamt1, loop1.feecurr1, loop1.tranrefno, loop1.tranamt, loop1.trancurr, loop1.feeamt1, loop1.feecurr1, NULL, 'F', 0, NULL, V_REVERSE_REASON, loop1.payerid, loop1.payeeref, loop1.switchref, NULL, NULL, V_REVERSE_REF, NULL);
                END LOOP;
                O_DBCURR := 'TZS';
                O_REQCODE := '';
                O_RESULT := 'S';
                EXCEPTION
                    WHEN others THEN
					GET STACKED DIAGNOSTICS v_error_stack = PG_EXCEPTION_CONTEXT;
              raise '% : %', sqlstate, sqlerrm;
                        O_RESULT := 'F';
            END;
        ELSE
            /* ** Rev Req from ABSAPAY Channels ** */
            IF (I_SERVCD = '2120') THEN /* ** Approve hold msg request * */
                <<EXCEP>>
                BEGIN
                    SELECT
                        j.reason, j.rev_ref
                        INTO STRICT V_REVERSE_REASON, V_REVERSE_REF
                        FROM  job005 AS j
                        WHERE j.suborgcode = I_SUBORG AND j.syscode = 'HP' AND j.paytype = I_PAYTYPE AND j.reqdate = I_REQDATE::TIMESTAMP WITHOUT TIME ZONE AND j.refno = I_REQREFNO AND j.reqsl = I_REQSL;

                    FOR loop1 IN
                    SELECT
                        *
                        FROM  pay001 AS r
                        WHERE r.suborgcode = I_SUBORG AND r.chcode = I_INITIATEBY AND r.paytype = I_PAYTYPE AND r.tranrefno = I_REQREFNO AND r.reqsl = I_REQSL
                    LOOP
                        O_FLOW := loop1.flow;
                        O_CHANNEL := loop1.chcode;
                        UPDATE  pay002
                        SET reqtime = loop1.reqtime, paydate = loop1.paydate, trantype = loop1.trantype, initiateby = loop1.chcode, org_amnt = loop1.tranamt, org_curr = loop1.trancurr, org_chrgamnt = loop1.feeamt1, org_chrgcurr = loop1.feecurr1, org_refno = loop1.tranrefno, rev_amount = loop1.tranamt, rev_curr = loop1.trancurr, rev_chrgamount = loop1.feeamt1, rev_chrgcurr = loop1.feecurr1, rev_type = 'F', isfinal_rev = 0, rev_reason = V_REVERSE_REASON, hold_state = 'REQUESTED', hold_amount = loop1.tranamt, hold_curr = loop1.trancurr, payerid = loop1.payerid, payeeid = loop1.payeeref, tran_switchref = loop1.switchref, payer_revref = V_REVERSE_REF, isrevapproved = 0
                            WHERE suborgcode = loop1.suborgcode AND chcode = loop1.chcode AND paytype = loop1.paytype AND reqdate = loop1.reqdate AND reqrefno = loop1.reqrefno AND tranrefno = loop1.tranrefno AND reqsl = loop1.reqsl;
                    END LOOP;
                    UPDATE  pay002 AS w
                    SET isholdapproved = 1, isrevapproved = 1
                        WHERE w.suborgcode = I_SUBORG AND w.reqsl = I_REQSL AND w.paytype = I_PAYTYPE AND w.tranrefno = I_REQREFNO;
                    O_RESCD := 'Approved';
                    O_RESDESC := V_REVERSE_REASON;
                    O_RESULT := 'S';
                    EXCEPTION
                        WHEN others THEN
						 GET STACKED DIAGNOSTICS v_error_stack = PG_EXCEPTION_CONTEXT;
              raise '% : %', sqlstate, sqlerrm;
                            O_RESULT := 'F';
                END;
            END IF;

            IF (I_SERVCD = '2110') THEN
                <<EXCEP>>
                BEGIN
                    SELECT
                        j.reason, j.rev_ref
                        INTO STRICT V_REVERSE_REASON, V_REVERSE_REF
                        FROM  job005 AS j
                        WHERE j.suborgcode = I_SUBORG AND j.syscode = 'HP' AND j.paytype = I_PAYTYPE AND j.reqdate = I_REQDATE::TIMESTAMP WITHOUT TIME ZONE AND j.refno = I_REQREFNO AND j.reqsl = I_REQSL;

                    FOR loop1 IN
                    SELECT
                        *
                        FROM  pay001 AS r
                        WHERE r.suborgcode = I_SUBORG AND r.chcode = I_INITIATEBY AND r.paytype = I_PAYTYPE AND r.reqsl = I_REQSL
                    LOOP
                        O_FLOW := loop1.flow;
                        O_TRANAMOUNT := loop1.tranamt::TEXT;
                        O_CHRGAMOUNT := loop1.feeamt1::TEXT;
                        O_CHRGCURR := loop1.feecurr1;
                        O_CRACCOUNT := loop1.s_account; /* ** ABSA customer account * */
                        v_creditcurr := loop1.trancurr;
                        v_creditbrn := loop1.s_brncode;
                        O_CHANNEL := loop1.chcode;
                        v_payerref := loop1.payerid;
                        v_destac := loop1.d_account;
                        v_payee_Name := loop1.s_acname;
                    END LOOP;
                    /* ** CBS Account Mapping (Note : Debit/source Ac : Tips Inward GL Ac / Destination Ac : ABSA Customer Account) * */
                    v_tranamnt := O_TRANAMOUNT;
                    O_DBCURR := 'TZS';
                    v_debibrn := v_creditbrn;
                    SELECT
                        crgl, acname
                        INTO STRICT O_DBACCOUNT, v_payer_Name
                        FROM  ledgermap
                        WHERE program = 'TIPS' AND usergroup = 'O' AND dcflg = 'C' AND trantype = 'T'; /* ** TIPS OUTWARD COLLECTION * */

                    IF (O_CRACCOUNT IS NOT NULL AND LENGTH(O_CRACCOUNT) = 10) THEN
                        v_creditbrn := SUBSTRING(O_CRACCOUNT, 1, 3);
                        O_CRACCOUNT := SUBSTRING(O_CRACCOUNT, 4);
                    END IF;

                    IF (O_DBACCOUNT IS NOT NULL AND LENGTH(O_DBACCOUNT) = 10) THEN
                        v_debibrn := SUBSTRING(O_DBACCOUNT, 1, 3);
                        O_DBACCOUNT := SUBSTRING(O_DBACCOUNT, 4);
                    END IF;
                    O_NARRATION := CONCAT_WS('', 'TIPS: DEST: ', v_destac, ' Payer Ref: ', v_payerref);
                    O_REQCODE := '';
                    O_BRNCODE := CONCAT_WS('', v_debibrn, '|', v_debibrn, '|', v_creditbrn, '|');
                    V_COUNT := 0;
                    V_COUNT := V_COUNT + 1;
                    INSERT INTO  transactions (suborgcode, trantype, trancode, systemdate, transeq, legsl, branchcd, trandate, chcode, chrefno, dbcr, amount, trancurr, sysamount, syscurr, accountno, iban, swiftcd, ledgerno, paytype, charges, chgcode, remarks, euser, edate, auser, adate, cuser, cdate, status, invoiceno, syscode, paysl, addinfo2, addinfo3)
                    VALUES (I_SUBORG, 'TRANSFER', 'TD', (CLOCK_TIMESTAMP() AT TIME ZONE COALESCE(CURRENT_SETTING('aws_oracle_ext.tz', TRUE), 'UTC'))::TIMESTAMP(0), V_COUNT, 1, v_creditbrn, I_REQDATE, O_CHANNEL, I_REQREFNO, 'D', v_tranamnt, v_creditcurr, O_TRANAMOUNT, v_creditcurr, NULL, NULL, NULL, O_DBACCOUNT, I_PAYTYPE, NULL, NULL, O_NARRATION, I_INITIATEBY, (CLOCK_TIMESTAMP() AT TIME ZONE COALESCE(CURRENT_SETTING('aws_oracle_ext.tz', TRUE), 'UTC'))::TIMESTAMP(0), I_INITIATEBY, (CLOCK_TIMESTAMP() AT TIME ZONE COALESCE(CURRENT_SETTING('aws_oracle_ext.tz', TRUE), 'UTC'))::TIMESTAMP(0), NULL, NULL, 'PENDING', NULL, 'HP', I_REQSL, v_payer_Name, v_payee_Name);
                    INSERT INTO  transactions (suborgcode, trantype, trancode, systemdate, transeq, legsl, branchcd, trandate, chcode, chrefno, dbcr, amount, trancurr, sysamount, syscurr, accountno, iban, swiftcd, ledgerno, paytype, charges, chgcode, remarks, euser, edate, auser, adate, cuser, cdate, status, invoiceno, syscode, paysl, addinfo2, addinfo3)
                    VALUES (I_SUBORG, 'TRANSFER', 'TC', (CLOCK_TIMESTAMP() AT TIME ZONE COALESCE(CURRENT_SETTING('aws_oracle_ext.tz', TRUE), 'UTC'))::TIMESTAMP(0), V_COUNT, 2, v_creditbrn, I_REQDATE, O_CHANNEL, I_REQREFNO, 'C', v_tranamnt, v_creditcurr, O_TRANAMOUNT, v_creditcurr, O_CRACCOUNT, NULL, NULL, NULL, I_PAYTYPE, NULL, NULL, O_NARRATION, I_INITIATEBY, (CLOCK_TIMESTAMP() AT TIME ZONE COALESCE(CURRENT_SETTING('aws_oracle_ext.tz', TRUE), 'UTC'))::TIMESTAMP(0), I_INITIATEBY, (CLOCK_TIMESTAMP() AT TIME ZONE COALESCE(CURRENT_SETTING('aws_oracle_ext.tz', TRUE), 'UTC'))::TIMESTAMP(0), NULL, NULL, 'PENDING', NULL, 'HP', I_REQSL, v_payer_Name, v_payee_Name);
                    O_RESULT := 'S';
                    EXCEPTION
                        WHEN others THEN
						GET STACKED DIAGNOSTICS v_error_stack = PG_EXCEPTION_CONTEXT;
              raise '% : %', sqlstate, sqlerrm;
                            O_RESULT := 'F';
                END;
            END IF;
        END IF;
    END IF;
END;
$$;

alter function proc_o_rev_requestpost(text, text, text, text, text, text, text, out text, out text, out text, out text, out text, out text, out text, out text, out text, out text, out text, out text, out text, out text, out text, out text, out text, out text, out text, out text, out text, out text, out text, out text) owner to postgres;

