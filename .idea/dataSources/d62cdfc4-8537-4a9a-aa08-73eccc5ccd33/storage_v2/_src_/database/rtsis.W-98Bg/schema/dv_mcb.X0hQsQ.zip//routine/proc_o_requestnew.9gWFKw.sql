create function proc_o_requestnew(i_suborg text, i_chncd text, i_paytype text, i_reqdate text, i_reqrefno text, i_reqsl text, i_servcd text, OUT o_status text, OUT o_rescd text, OUT o_resdesc text, OUT o_payload text, OUT o_signpayload text, OUT o_headerid text, OUT o_method text, OUT o_uri text, OUT o_format text, OUT o_protocol text, OUT o_tranamount text, OUT o_dbcurr text, OUT o_chrgamount text, OUT o_chrgcurr text, OUT o_dbaccount text, OUT o_craccount text, OUT o_flow text) returns record
    language plpgsql
as
$$
DECLARE
    v_format CHARACTER VARYING(10) := NULL;
    v_protocol CHARACTER VARYING(10) := NULL;
    v_method CHARACTER VARYING(10) := NULL;
    v_chtype CHARACTER VARYING(20) := NULL;
    v_uri CHARACTER VARYING(250) := NULL;
    v_payload CHARACTER VARYING(2000) := NULL;
    v_signpayload CHARACTER VARYING(2000) := NULL;
    v_flow CHARACTER VARYING(20) := NULL;
    v_Reference_Id CHARACTER VARYING(50) := NULL;
    V_TRANAMOUNT CHARACTER VARYING(50) := NULL;
    V_CHRGAMOUNT CHARACTER VARYING(50) := NULL;
    V_DBCURR CHARACTER VARYING(50) := NULL;
    V_DBACCOUNT CHARACTER VARYING(50) := NULL;
    V_CRACCOUNT CHARACTER VARYING(500) := NULL;
    
    v_error_stack text := NULL;
    V_REQSSL CHARACTER VARYING(500) := NULL;
    loop1 RECORD;
BEGIN
    SELECT
        w.format, w.protocol, w.method, w.chtype, w.uri, w.payload, w.signpayload, w.headerid, w.method, w.uri, w.format, w.protocol
        INTO STRICT v_format, v_protocol, v_method, v_chtype, v_uri, v_payload, v_signpayload, O_HEADERID, O_METHOD, O_URI, O_FORMAT, O_PROTOCOL
        FROM  webservice001 AS w
        WHERE w.suborgcode = I_SUBORG AND w.syscode = 'HP' AND w.chcode = I_PAYTYPE AND w.servicecd = I_SERVCD AND w.flow = 'O';
   
   FOR loop1 IN
    SELECT
        *
        FROM  request002 AS r
        WHERE r.suborgcode = I_SUBORG AND r.syscode = 'HP' AND r.chcode = I_CHNCD AND r.paytype = I_PAYTYPE AND r.reqdate = current_date AND r.reqrefno = I_REQREFNO AND r.reqsl = I_REQSL
    LOOP
        <<PAYLOAD>>
        BEGIN
            /* ************************************************** TIPS ************************************************** */
            IF (I_PAYTYPE = 'TIPS') THEN
                IF (loop1.flow = 'O') THEN
                    v_payload := replace(v_payload, '~tran_amount~', coalesce(loop1.tranamt::TEXT, ''));
                    v_payload := replace(v_payload, '~tran_currency~', coalesce(loop1.trancurr, ''));
                    v_payload := replace(v_payload, '~description~', coalesce(loop1.remarks, ''));
                    v_payload := replace(v_payload, '~fee_amount~', coalesce(loop1.feeamt1::TEXT, ''));
                    v_payload := replace(v_payload, '~fee_currency~', coalesce(loop1.feecurr1, ''));
                    /* ************** Payee Information ************* */
                    v_payload := replace(v_payload, '~pye_accountCategory~', coalesce(loop1.d_accategory, ''));
                    v_payload := replace(v_payload, '~pye_accountType~', coalesce(loop1.d_actype, ''));
                    v_payload := replace(v_payload, '~pye_fspId~', coalesce(loop1.d_fspid, ''));
                    v_payload := replace(v_payload, '~pye_fullName~', coalesce(loop1.d_acname, ''));
                    v_payload := replace(v_payload, '~pye_identifierType~', coalesce(loop1.d_identifiertype, ''));

                    IF (loop1.d_identifiertype = 'ALIAS') THEN
                        v_payload := replace(v_payload, '~pye_identifier~', coalesce(loop1.d_receiverid, ''));
                    END IF;

                    IF (loop1.d_identifiertype = 'BANK') THEN
                        v_payload := replace(v_payload, '~pye_identifier~', coalesce(loop1.d_account, ''));
                    END IF;

                    IF (loop1.d_identifiertype = 'MSISDN') THEN
                        v_payload := replace(v_payload, '~pye_identifier~', coalesce(loop1.d_mobile, ''));
                    END IF;
                    v_payload := replace(v_payload, '~pye_identifier~', coalesce(loop1.d_account, ''));
                    v_payload := replace(v_payload, '~pye_ident_type~', coalesce(loop1.d_identifytype, ''));
                    v_payload := replace(v_payload, '~pye_ident_value~', coalesce(loop1.d_identifyvalue, ''));
                    /* ************** Payer Information ************* */
                    v_payload := replace(v_payload, '~pyr_accountCategory~', coalesce(loop1.s_accategory, ''));
                    v_payload := replace(v_payload, '~pyr_accountType~', coalesce(loop1.s_actype, ''));
                    v_payload := replace(v_payload, '~pyr_fspId~', coalesce(loop1.s_fspid, ''));
                    v_payload := replace(v_payload, '~pyr_fullName~', coalesce(loop1.s_acname, ''));
                    v_payload := replace(v_payload, '~pyr_identifierType~', coalesce(loop1.s_identifiertype, ''));

                    IF (loop1.s_identifiertype = 'ALIAS') THEN
                        v_payload := replace(v_payload, '~pyr_identifier~', coalesce(loop1.s_senderid, ''));
                    END IF;

                    IF (loop1.s_identifiertype = 'BANK') THEN
                        v_payload := replace(v_payload, '~pyr_identifier~', coalesce(loop1.s_account, ''));
                    END IF;

                    IF (loop1.s_identifiertype = 'MSISDN') THEN
                        v_payload := replace(v_payload, '~pyr_identifier~', coalesce(loop1.s_mobile, ''));
                    END IF;
                    v_payload := replace(v_payload, '~pyr_identifier~', coalesce(loop1.s_account, ''));
                    v_payload := replace(v_payload, '~pyr_ident_type~', coalesce(loop1.s_identifytype, ''));
                    v_payload := replace(v_payload, '~pyr_ident_value~', coalesce(loop1.s_identifyvalue, ''));
                    v_payload := replace(v_payload, '~payerRef~', coalesce(loop1.tranrefno, ''));
                    /* ************** TransactionType Information ************* */
                    v_payload := replace(v_payload, '~initiator~', coalesce(loop1.sender_info, ''));
                    /* 'CUSTOMER' */
                    v_payload := replace(v_payload, '~initiatorType~', coalesce(loop1.initatedby, ''));
                    /* 'SENDER' */
                    v_payload := replace(v_payload, '~scenario~', coalesce(loop1.trantype, ''));
                    /* 'TRANSFER' */
                END IF;
                v_flow := loop1.flow;
                V_TRANAMOUNT := loop1.tranamt::TEXT;
                V_TRANAMOUNT := loop1.tranamt::TEXT;
                V_CHRGAMOUNT := loop1.feeamt1::TEXT;
                V_DBCURR := loop1.trancurr;
                V_DBACCOUNT := loop1.s_account;
                V_CRACCOUNT := loop1.d_account;

                IF (loop1.rescode IS NULL OR loop1.rescode = '') THEN
                    O_RESDESC := 'S';
                ELSE
                    O_RESCD := loop1.rescode;
                    O_RESDESC := 'F';
                END IF;
            END IF;
			
            O_PAYLOAD := v_payload;
            O_SIGNPAYLOAD := v_signpayload;
            O_FLOW := v_flow;
            O_TRANAMOUNT := V_TRANAMOUNT;
            O_CHRGAMOUNT := V_CHRGAMOUNT;
            O_DBCURR := V_DBCURR;
            O_DBACCOUNT := V_DBACCOUNT;
            O_CRACCOUNT := V_CRACCOUNT;
            
            V_REQSSL := loop1.reqsl;
			
			 IF (loop1.flow = 'I') THEN
		               INSERT INTO  pay001 (suborgcode, chcode, paytype, flow, tranbrncode, reqdate, reqrefno, tranrefno, reqsl, reqtime
            , paydate, trantype, amounttype, reqtype, status, errcd, rescode, tranamt, trancurr, serporcd
            , payerid, debitamt, debitcurr, creditamt, creditcurr, s_account, d_account, s_glno, d_glno, chqeueno
            , s_bankbic, d_bankbic, s_acname, d_acname, initiator_cif, s_clientno, d_clientno, feeamt1, feecurr1, feeamt2
            , feecurr2, feeamt3, feecurr3, feeamt4, feecurr4, invoiceno, s_iban, d_iban, s_brncode, d_brncode
            , s_actype, d_actype, s_address, d_address, s_emailid, d_emailid, s_mobile, d_mobile, s_telephone, d_telephone
            , sender_info, receiver_info, payeeref, receiptno, purposecd, s_identifiertype, d_identifiertype, s_accategory, d_accategory, s_fspid
            , d_fspid, s_identifytype, d_identifytype, s_identifyvalue, d_identifyvalue, d_receiverid, s_senderid, remarks, euser, edate
            , auser, adate, cuser, cdate, ruser, rdate)
            VALUES (loop1.suborgcode, loop1.chcode, loop1.paytype, loop1.flow, loop1.s_brncode, current_date, loop1.reqrefno, loop1.tranrefno, TO_NUMBER(loop1.reqsl,'9999999999') , current_timestamp
                    , current_date, loop1.trantype, loop1.amounttype, loop1.reqtype, loop1.status, loop1.errcd, loop1.rescode, TO_NUMBER(loop1.tranamt,'9999999999'), loop1.trancurr, loop1.serporcd
                    , loop1.payerid,'0', loop1.debitcurr,  '0', loop1.creditcurr, loop1.s_account, loop1.d_account, NULL, NULL, NULL, loop1.s_bankbic
                    , loop1.d_bankbic, loop1.s_acname, loop1.d_acname, loop1.initiator_cif, loop1.s_clientno, loop1.d_clientno,  '0','TZS','0'
                    , loop1.feecurr2, '0', loop1.feecurr3,'0', loop1.feecurr4, loop1.invoiceno, loop1.s_iban, loop1.d_iban, loop1.s_brncode, loop1.d_brncode
                    , loop1.s_actype, loop1.d_actype, loop1.s_address, loop1.d_address, loop1.s_emailid, loop1.d_emailid, loop1.s_mobile, loop1.d_mobile, loop1.s_telephone, loop1.d_telephone
                    , loop1.sender_info, loop1.receiver_info, loop1.payeeref, loop1.receiptno, loop1.purposecd, loop1.s_identifiertype, loop1.d_identifiertype, loop1.s_accategory, loop1.d_accategory, loop1.s_fspid
                    , loop1.d_fspid, loop1.s_identifytype, loop1.d_identifytype, loop1.s_identifyvalue, loop1.d_identifyvalue, loop1.d_receiverid, loop1.s_senderid, loop1.remarks, 'SYSTEM', current_timestamp
                    , 'SYSTEM', current_timestamp, '', current_timestamp, '', current_timestamp);
			 END IF;
			
  
      IF (loop1.flow = 'O') THEN
         
          INSERT INTO  pay001 (suborgcode, chcode, paytype, flow, tranbrncode, reqdate, reqrefno, tranrefno, reqsl, reqtime
            , paydate, trantype, amounttype, reqtype, status, errcd, rescode, tranamt, trancurr, serporcd
            , payerid, debitamt, debitcurr, creditamt, creditcurr, s_account, d_account, s_glno, d_glno, chqeueno
            , s_bankbic, d_bankbic, s_acname, d_acname, initiator_cif, s_clientno, d_clientno, feeamt1, feecurr1, feeamt2
            , feecurr2, feeamt3, feecurr3, feeamt4, feecurr4, invoiceno, s_iban, d_iban, s_brncode, d_brncode
            , s_actype, d_actype, s_address, d_address, s_emailid, d_emailid, s_mobile, d_mobile, s_telephone, d_telephone
            , sender_info, receiver_info, payeeref, receiptno, purposecd, s_identifiertype, d_identifiertype, s_accategory, d_accategory, s_fspid
            , d_fspid, s_identifytype, d_identifytype, s_identifyvalue, d_identifyvalue, d_receiverid, s_senderid, remarks, euser, edate
            , auser, adate, cuser, cdate, ruser, rdate)
            VALUES (loop1.suborgcode, loop1.chcode, loop1.paytype, loop1.flow, loop1.s_brncode, current_date, loop1.reqrefno, loop1.tranrefno, TO_NUMBER(loop1.reqsl,'9999999999') , current_timestamp
                    , current_date, loop1.trantype, loop1.amounttype, loop1.reqtype, loop1.status, loop1.errcd, loop1.rescode, TO_NUMBER(loop1.tranamt,'9999999999'), loop1.trancurr, loop1.serporcd
                    , loop1.payerid,'0', loop1.debitcurr,  '0', loop1.creditcurr, loop1.s_account, loop1.d_account, NULL, NULL, NULL, loop1.s_bankbic
                    , loop1.d_bankbic, loop1.s_acname, loop1.d_acname, loop1.initiator_cif, loop1.s_clientno, loop1.d_clientno,  TO_NUMBER(loop1.feeamt1,'9999999999'),loop1.feecurr1,TO_NUMBER(loop1.feeamt1,'9999999999')
                    , loop1.feecurr2, TO_NUMBER(loop1.feeamt1,'9999999999'), loop1.feecurr3,TO_NUMBER(loop1.feeamt1,'9999999999'), loop1.feecurr4, loop1.invoiceno, loop1.s_iban, loop1.d_iban, loop1.s_brncode, loop1.d_brncode
                    , loop1.s_actype, loop1.d_actype, loop1.s_address, loop1.d_address, loop1.s_emailid, loop1.d_emailid, loop1.s_mobile, loop1.d_mobile, loop1.s_telephone, loop1.d_telephone
                    , loop1.sender_info, loop1.receiver_info, loop1.payeeref, loop1.receiptno, loop1.purposecd, loop1.s_identifiertype, loop1.d_identifiertype, loop1.s_accategory, loop1.d_accategory, loop1.s_fspid
                    , loop1.d_fspid, loop1.s_identifytype, loop1.d_identifytype, loop1.s_identifyvalue, loop1.d_identifyvalue, loop1.d_receiverid, loop1.s_senderid, loop1.remarks, 'SYSTEM', current_timestamp
                    , 'SYSTEM', current_timestamp, '', current_timestamp, '', current_timestamp);
	
			 END IF;		
					
                    
           EXCEPTION
                WHEN others THEN
                GET STACKED DIAGNOSTICS v_error_stack = PG_EXCEPTION_CONTEXT;
              raise '% : %', sqlstate, sqlerrm;
        END;
    END LOOP;
END;
$$;

alter function proc_o_requestnew(text, text, text, text, text, text, text, out text, out text, out text, out text, out text, out text, out text, out text, out text, out text, out text, out text, out text, out text, out text, out text, out text) owner to postgres;

