create function spcodecheck(programid character varying, spcode character varying, OUT curr2 character varying, OUT dbacno2 character varying, OUT cracno2 character varying, OUT curr character varying, OUT dbacon2 character varying, OUT cracn2 character varying, OUT w_cracna character varying, OUT chargemats character varying) returns record
    language plpgsql
as
$$
BEGIN
  CURR2:= 0;
  DBACNO2:= 0;
  CRACNO2 := 0;
  CURR :=0;
  DBACON2:=0;
  CRACN2:=0;
  W_CRACNA:=0;
  CHARGEMATS:=0;

    IF (UPPER(TRIM(PROGRAMID)) IN ('SIMBANETPAY' , 'MSCPAY', 'UDOMPAY' ,'SJUIT', 'GEPGPAY','GEPGPAYNEW','TAXCOLL')) THEN

        -- SQLINES LICENSE FOR EVALUATION USE ONLY
        SELECT  CURR2 INTO CURR FROM LEDGERMAP  WHERE USERGROUP =SPCODE AND PROGRAM =  UPPER(TRIM(PROGRAMID)) AND TRANTYPE ='D' ;

        -- SQLINES LICENSE FOR EVALUATION USE ONLY
        SELECT   DBACNO2 INTO DBACON2  FROM LEDGERMAP  WHERE USERGROUP =SPCODE AND PROGRAM =  UPPER(TRIM(PROGRAMID)) AND TRANTYPE ='D' ;

        -- SQLINES LICENSE FOR EVALUATION USE ONLY
        SELECT   CRACNO2 INTO CRACN2 FROM LEDGERMAP  WHERE USERGROUP =SPCODE AND PROGRAM =  UPPER(TRIM(PROGRAMID)) AND TRANTYPE ='D';


        -- SQLINES LICENSE FOR EVALUATION USE ONLY
        SELECT  CHARGEMAT INTO CHARGEMATS FROM CHARGE001  WHERE SUBCODE1 =  UPPER(TRIM(PROGRAMID))  ;



      END IF;




END;
$$;

alter function spcodecheck(varchar, varchar, out varchar, out varchar, out varchar, out varchar, out varchar, out varchar, out varchar, out varchar) owner to postgres;

