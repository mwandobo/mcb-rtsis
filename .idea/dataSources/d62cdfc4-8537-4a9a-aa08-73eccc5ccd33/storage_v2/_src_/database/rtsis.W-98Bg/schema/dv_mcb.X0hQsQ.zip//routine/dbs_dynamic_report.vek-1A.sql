create function dbs_dynamic_report(suborgcode character varying, brncode character varying, prodcode character varying, fdate character varying, OUT reportsl integer, OUT message character varying) returns record
    language plpgsql
as
$$
 DECLARE
 D_TEMPSERIAL INT = 0;
 D_ROLENAME VARCHAR(1000);
 d_tracker INT = 1;
 D_AMOUNT VARCHAR(50) = 0;
 FROM_DT TIMESTAMP(0);
 TO_DT TIMESTAMP(0);

begin

  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  SELECT SEQ_REPORT.NEXTVAL INTO D_TEMPSERIAL ;


 -- SQLINES LICENSE FOR EVALUATION USE ONLY
 INSERT INTO REPORT002(suborgcode, serial, column1, column2, column3)
     VALUES (SUBORGCODE, D_TEMPSERIAL,'H','Loan Repayment', 'Loan Repayment');

 -- SQLINES LICENSE FOR EVALUATION USE ONLY
 INSERT INTO REPORT002(suborgcode, serial, column1, column2, column3, COLUMN4, COLUMN5,Column6, COLUMN7, COLUMN8, COLUMN9, COLUMN10,
 column11, column12, column13, COLUMN14, COLUMN15, Column16, COLUMN17, COLUMN18, COLUMN19, COLUMN20, column21, column22, column23, COLUMN24, COLUMN25, COLUMN26)
  VALUES (SUBORGCODE, D_TEMPSERIAL,'C','S.No','Loan A/C No','Name', 'Loan Amount', 'Disbursed Amount','Installment Due', 'Repayment Schedule',
  'Total Payable' , 'Total Paid', 'Arrears', 'Capital Outstanding', 'Additional Interest', 'Total Outstanding', 'Last Date', 'Last Repayment Amount',
  'Overdue Mark Date', 'No of Days', 'Security Value', 'Interest Rate', 'Purpose', 'Loan Duration', 'Loan Officer', 'Recovery Officer',
  'Legal Officer','Action');

/* SQLINES DEMO *** select distinct ii.chqcurr  from invoice002 ii WHERE ii.suborgcode = SUBORGCODE
   and ii.custtype = INVTYPE )  LOOP


      <<D_AMOUNTFETCH>>
      BEGIN
        FROM_DT := TO_DATE(FDATE, 'DD-MON-YYYY');
        TO_DT := TO_DATE(TDATE, 'DD-MON-YYYY');
       WHILE NOT FROM_DT > TO_DT LOOP
         null;

         if (length(trim(SUBOFF)) = 1 ) THEN
         FOR LOOP2 IN (select distinct ii.chqcurr,ii.mop ,ii.suboffcd from invoice002 ii WHERE ii.suborgcode = SUBORGCODE
          and ii.custtype = INVTYPE  and ii.suboffcd = SUBOFF  )  LOOP
              select sum(ii.chqamount) into d_amount from invoice002 ii where ii.suborgcode = SUBORGCODE
              and ii.custtype = INVTYPE and ii.mop =loop2.mop  and ii.suboffcd = SUBOFF
        and ii.invdate = from_dt and ii.chqcurr = loop2.chqcurr ;

             IF(  d_amount IS NULL ) THEN
            D_AMOUNT := 0;
            END IF;


              INSERT INTO REPORT002(suborgcode, serial, column1, column2, column3, column4, column5, column6 ,column7,column8, column9)
              VALUES (SUBORGCODE, D_TEMPSERIAL,'D',d_tracker, INVTYPE , loop2.suboffcd ,  from_dt, loop2.chqcurr ,decode(loop2.mop,'T','Transfer','C','Cash','I','Cheque',loop2.mop),
              D_AMOUNT, D_TEMPSERIAL);
              d_tracker := d_tracker + 1;


         end loop;

         ELSif ( length(trim(MOP)) = 1 ) THEN

           FOR LOOP2 IN (select distinct ii.chqcurr,ii.mop ,ii.suboffcd from invoice002 ii WHERE ii.suborgcode = SUBORGCODE
          and ii.custtype = INVTYPE  and ii.suboffcd = SUBOFF  )  LOOP
              select sum(ii.chqamount) into d_amount from invoice002 ii where ii.suborgcode = SUBORGCODE
              and ii.custtype = INVTYPE and ii.mop =loop2.mop  and ii.suboffcd = SUBOFF and ii.invdate = from_dt and ii.chqcurr = loop2.chqcurr ;

             IF(  d_amount IS NULL ) THEN
            D_AMOUNT := 0;
            END IF;


              INSERT INTO REPORT002(suborgcode, serial, column1, column2, column3, column4, column5, column6 ,column7 ,column8,COLUMN9)
              VALUES (SUBORGCODE, D_TEMPSERIAL,'D',d_tracker, INVTYPE, loop2.suboffcd  , from_dt, loop2.chqcurr ,decode(loop2.mop,'T','Transfer','C','Cash','I','Cheque',loop2.mop),
              D_AMOUNT, D_TEMPSERIAL);
              d_tracker := d_tracker + 1;

         end loop;

   else
     FOR LOOP2 IN (select distinct ii.chqcurr , ii.suboffcd from invoice002 ii WHERE ii.suborgcode = SUBORGCODE
          and ii.custtype = INVTYPE )  LOOP
              select sum(ii.chqamount) into d_amount from invoice002 ii where ii.suborgcode = SUBORGCODE
              and ii.custtype = INVTYPE and ii.suboffcd = loop2.suboffcd
        and ii.invdate = from_dt and ii.chqcurr = loop2.chqcurr ;


              INSERT INTO REPORT002(suborgcode, serial, column1, column2, column3, column4, column5, column6,column7 ,column8, COLUMN9)
              VALUES (SUBORGCODE, D_TEMPSERIAL,'D',d_tracker, INVTYPE, loop2.suboffcd ,  from_dt, loop2.chqcurr ,'ALL',
              D_AMOUNT, D_TEMPSERIAL);
              d_tracker := d_tracker + 1;
         end loop;

   end if;

         FROM_DT := FROM_DT + 1;
        end loop;

      EXCEPTION WHEN OTHERS THEN
        FROM_DT := FROM_DT + 1;
        D_AMOUNT := '0';
      END D_AMOUNTFETCH;


  END LOOP;
*/

    REPORTSL := D_TEMPSERIAL;
    /* COMMIT; */

end;
$$;

alter function dbs_dynamic_report(varchar, varchar, varchar, varchar, out integer, out varchar) owner to postgres;

