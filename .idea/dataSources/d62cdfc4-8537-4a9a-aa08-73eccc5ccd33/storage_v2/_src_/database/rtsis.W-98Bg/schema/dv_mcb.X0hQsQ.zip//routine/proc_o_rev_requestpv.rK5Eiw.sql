create function proc_o_rev_requestpv(i_suborg text, i_initiateby text, i_paytype text, i_reqdate text, i_reqrefno text, i_reqsl text, i_servcd text, OUT o_status text, OUT o_rescd text, OUT o_resdesc text, OUT o_payload text, OUT o_signpayload text, OUT o_headerid text, OUT o_method text, OUT o_uri text, OUT o_format text, OUT o_protocol text, OUT o_flow text, OUT o_tranamount text, OUT o_dbcurr text, OUT o_chrgamount text, OUT o_chrgcurr text, OUT o_dbaccount text, OUT o_craccount text, OUT o_chrgaccount text, OUT o_narration text, OUT o_reqcode text, OUT o_brncode text, OUT o_channel text, OUT o_result text, OUT o_message text) returns record
    language plpgsql
as
$$
DECLARE

v_debitcurr CHARACTER VARYING(10) := null;
v_debibrn CHARACTER VARYING(50) := null;
v_creditcurr CHARACTER VARYING(10) := null;
v_creditbrn CHARACTER VARYING(50) := null;
v_chrg_account CHARACTER VARYING(50) := null;
v_tranamnt CHARACTER VARYING(50) := null;
v_chrgamnt CHARACTER VARYING(50) := null;
V_REVERSE_REASON CHARACTER VARYING(250) := '';
V_REJECT_REASON CHARACTER VARYING(250) := '';
V_REVERSE_REF CHARACTER VARYING(50) := '';
V_APPROVAL CHARACTER VARYING(50) := '';
V_COUNT NUMERIC(10) := 0;

    v_error_stack text := NULL;

loop1 record;

 begin
    
  /*************************************************** TIPS ***************************************************/
      
   if(I_PAYTYPE = 'TIPS') then
   
       if(I_INITIATEBY = 'TIPS') then  /*** Rev Req from Tips ***/
     
          if(I_SERVCD = '2120') then /***  Tips has initiated the Hold Request to MCB and we have to Proceed Hold cbs posting ***/
      
           <<EXCEP>>
             BEGIN
             
             select j.reason, j.rev_ref into V_REVERSE_REASON, V_REVERSE_REF from job005 j where j.suborgcode = I_SUBORG and j.syscode = 'HP' and  
             j.paytype = I_PAYTYPE and j.reqdate = I_REQDATE::TIMESTAMP WITHOUT TIME ZONE and j.refno = I_REQREFNO and j.reqsl = I_REQSL; 
              
             for loop1 in (select * from PAY001 r where r.suborgcode = I_SUBORG and r.paytype = I_PAYTYPE 
               and r.TRANREFNO = I_REQREFNO and r.reqsl = I_REQSL) loop
             
                 insert into pay002 (SUBORGCODE, CHCODE, PAYTYPE, REQDATE, REQREFNO, TRANREFNO, REQSL, REQTIME, PAYDATE, TRANTYPE, INITIATEBY,
                 ORG_AMNT, ORG_CURR, ORG_CHRGAMNT, ORG_CHRGCURR, ORG_REFNO, REV_AMOUNT, REV_CURR, REV_CHRGAMOUNT, REV_CHRGCURR, REV_REFNO, REV_TYPE,
                 ISFINAL_REV, REV_CODE, REV_REASON, HOLD_STATE, HOLD_AMOUNT, HOLD_CURR, PAYERID, PAYEEID, TRAN_SWITCHREF, REV_SWITCHREF, rev_status, payer_revref, payee_revref,
                 ISHOLDAPPROVED, ISREVAPPROVED, HOLDREJREASON, REVREJREASON)
                 values
                 (loop1.suborgcode, loop1.chcode, loop1.paytype, loop1.reqdate, loop1.reqrefno, loop1.tranrefno, loop1.reqsl, loop1.reqtime, loop1.paydate, loop1.trantype, 'TIPS',
                 loop1.tranamt, loop1.trancurr, loop1.feeamt1, loop1.feecurr1, loop1.tranrefno, loop1.tranamt, loop1.trancurr, loop1.feeamt1, loop1.feecurr1, null, 'F',
                 0, null, V_REVERSE_REASON, 'REQUESTED', loop1.tranamt, loop1.trancurr, loop1.payerid, loop1.payeeref, loop1.switchref, null, null, V_REVERSE_REF , null, 
                 1, 0, null, null);
                 
                 O_DBACCOUNT := loop1.d_account;  /*** MCB customer account **/
                 v_debibrn := loop1.d_brncode;
                 O_FLOW := loop1.flow;
				 
				 
                     
             end loop;
			 
			 
                 
             select  w.payload, w.signpayload, w.headerid, w.method, w.uri, w.format, w.protocol into
             O_PAYLOAD, O_SIGNPAYLOAD, O_HEADERID, O_METHOD, O_URI, O_FORMAT, O_PROTOCOL from webservice001 w    
             where w.suborgcode = I_SUBORG and w.syscode = 'HP' and w.chcode = I_PAYTYPE and w.servicecd = I_SERVCD and w.flow = 'O';
         
             /*select r.d_account, r.d_brncode, r.flow into O_DBACCOUNT, v_debibrn, O_FLOW from PAY001 r where r.suborgcode = I_SUBORG and r.paytype = I_PAYTYPE 
             and r.reqsl = I_REQSL;
              */
              
             for loop1 in (select * from PAY002 r where r.suborgcode = I_SUBORG and r.paytype = I_PAYTYPE 
               and r.reqsl = I_REQSL) loop
             
                 O_PAYLOAD :=  replace(O_PAYLOAD, '~payerReversalRef~', loop1.payer_revref);
                 O_PAYLOAD :=  replace(O_PAYLOAD, '~payerRef~', loop1.payerid);
                 O_PAYLOAD :=  replace(O_PAYLOAD, '~payeeRef~', loop1.payeeid); 
                 O_PAYLOAD :=  replace(O_PAYLOAD, '~switchRef~', loop1.tran_switchref);
                 O_PAYLOAD :=  replace(O_PAYLOAD, '~amount~', loop1.org_amnt);
                 O_PAYLOAD :=  replace(O_PAYLOAD, '~currency~', loop1.org_curr);
                 O_PAYLOAD :=  replace(O_PAYLOAD, '~reversalReason~', loop1.REV_REASON);
  
                 O_TRANAMOUNT  := loop1.org_amnt;     
                 O_CHRGAMOUNT  := loop1.rev_chrgamount;
                 O_CHRGCURR := loop1.rev_chrgcurr; 
                 v_debitcurr := loop1.org_curr;
                 v_creditcurr := loop1.org_curr;
                 O_CHANNEL := loop1.chcode;
                 
             end loop;
         
             /*** CBS Account Mapping (Note : Debit Ac : MCB Customer Account & Credit : Tips Hold GL Ac) **/
          
             v_creditbrn := v_debibrn;
             
             
              if(v_debibrn is null or v_debibrn = '') then v_debibrn := '1'; end if;       
              if(v_creditbrn is null or v_creditbrn = '') then v_creditbrn := '1';  end if;
               
             v_tranamnt := O_TRANAMOUNT;
             O_DBCURR  := 'TZS';
             
             O_CHRGAMOUNT := O_CHRGAMOUNT;
             
             select CRGL into O_CRACCOUNT from ledgermap where program = 'TIPS' and trantype = 'R'; /*** TIPS REVERSE GL Account **/

             O_NARRATION :=  'TIPS; ' || I_REQREFNO;  
             O_REQCODE := '-';      
             O_BRNCODE := v_debibrn || '|' || v_debibrn || '|' || v_creditbrn || '|';
             
             V_COUNT :=0;
              
             V_COUNT := V_COUNT + 1;
             
             Insert into transactions (SUBORGCODE, TRANTYPE, TRANCODE, SYSTEMDATE, TRANSEQ, LEGSL, BRANCHCD, TRANDATE, CHCODE, CHREFNO, DBCR, AMOUNT, TRANCURR, SYSAMOUNT, SYSCURR, ACCOUNTNO, IBAN, SWIFTCD, LEDGERNO, PAYTYPE, CHARGES, CHGCODE, REMARKS, EUSER, EDATE, AUSER, ADATE, CUSER, CDATE, STATUS, INVOICENO, SYSCODE, PAYSL)
             values (I_SUBORG, 'TRANSFER', 'TD', sysdate, V_COUNT, 1, v_debibrn, I_REQDATE, O_CHANNEL, I_REQREFNO, 'D', v_tranamnt, v_debitcurr, O_TRANAMOUNT, v_debitcurr, O_DBACCOUNT, null, null, null, I_PAYTYPE, null, null, O_NARRATION, I_INITIATEBY, sysdate, I_INITIATEBY, sysdate, null, null, 'PENDING', null, 'HP', I_REQSL);

             Insert into transactions (SUBORGCODE, TRANTYPE, TRANCODE, SYSTEMDATE, TRANSEQ, LEGSL, BRANCHCD, TRANDATE, CHCODE, CHREFNO, DBCR, AMOUNT, TRANCURR, SYSAMOUNT, SYSCURR, ACCOUNTNO, IBAN, SWIFTCD, LEDGERNO, PAYTYPE, CHARGES, CHGCODE, REMARKS, EUSER, EDATE, AUSER, ADATE, CUSER, CDATE, STATUS, INVOICENO, SYSCODE, PAYSL)
             values (I_SUBORG, 'TRANSFER', 'TC', sysdate, V_COUNT, 2, v_creditbrn, I_REQDATE, O_CHANNEL, I_REQREFNO, 'C', v_tranamnt, v_debitcurr, O_TRANAMOUNT, v_debitcurr, null, null, null, O_CRACCOUNT, I_PAYTYPE, null, null, O_NARRATION, I_INITIATEBY, sysdate, I_INITIATEBY, sysdate, null, null, 'PENDING', null, 'HP', I_REQSL);
            
             O_RESULT := 'S';
           Exception when others then
               O_RESULT := 'F';
           end EXCEP;
                     
         end if;
         
         if(I_SERVCD = '2120C') then /***  Cancel the Hold Request ***/
      
           <<EXCEP>>
             BEGIN
               
             select  w.payload, w.signpayload, w.headerid, w.method, w.uri, w.format, w.protocol into
             O_PAYLOAD, O_SIGNPAYLOAD, O_HEADERID, O_METHOD, O_URI, O_FORMAT, O_PROTOCOL from webservice001 w    
             where w.suborgcode = I_SUBORG and w.syscode = 'HP' and w.chcode = I_PAYTYPE and w.servicecd = '2120' and w.flow = 'O';
         
             update pay002 set HOLD_STATE = 'CANCELLED' where PAYTYPE = I_PAYTYPE and REQREFNO = I_REQREFNO and REQSL = I_REQSL;
           
             for loop1 in (select * from PAY001 r where r.suborgcode = I_SUBORG and r.paytype = I_PAYTYPE 
               and r.TRANREFNO = I_REQREFNO and r.reqsl = I_REQSL) loop
             
                 O_CRACCOUNT := loop1.d_account;  /*** MCB customer account **/
                 v_creditbrn := loop1.d_brncode;
                 O_FLOW := loop1.flow;
                     
             end loop; 
             
             for loop1 in (select * from PAY002 r where r.suborgcode = I_SUBORG and r.paytype = I_PAYTYPE 
               and r.reqsl = I_REQSL) loop
                        
                 O_PAYLOAD :=  replace(O_PAYLOAD, '~payerReversalRef~', loop1.payer_revref);
                 O_PAYLOAD :=  replace(O_PAYLOAD, '~payerRef~', loop1.payerid);
                 O_PAYLOAD :=  replace(O_PAYLOAD, '~payeeRef~', loop1.payeeid); 
                 O_PAYLOAD :=  replace(O_PAYLOAD, '~switchRef~', loop1.tran_switchref);
                 O_PAYLOAD :=  replace(O_PAYLOAD, '~amount~', loop1.org_amnt);
                 O_PAYLOAD :=  replace(O_PAYLOAD, '~currency~', loop1.org_curr);
                 O_PAYLOAD :=  replace(O_PAYLOAD, '~reversalReason~', loop1.REV_REASON);
                 
                 --O_PAYLOAD :=  replace(O_PAYLOAD, '~reversalState~', 'CANCELLED');
                 --O_PAYLOAD :=  replace(O_PAYLOAD, '~reversalReason~', loop1.REV_REASON);                 
                 
                 O_TRANAMOUNT  := loop1.org_amnt;     
                 O_CHRGAMOUNT  := loop1.rev_chrgamount;
                 O_CHRGCURR := loop1.rev_chrgcurr; 
                 v_debitcurr := loop1.org_curr;
                 v_creditcurr := loop1.org_curr;
                 O_CHANNEL := loop1.chcode;
                            
             end loop;
             
             /*** CBS Account Mapping (Note : Debit/source Ac : Tips Rev GL Ac & Credit/Destination Ac : MCB Customer Account) **/
          
             v_debibrn := v_creditbrn;
             
             if(v_debibrn is null or v_debibrn = '') then v_debibrn := '1'; end if;       
             if(v_creditbrn is null or v_creditbrn = '') then v_creditbrn := '1';  end if;
              
             v_tranamnt := O_TRANAMOUNT;
             O_DBCURR  := 'TZS';
          
             -- O_DBACCOUNT := 'G-' || '420002MCB';   /*** TIPS REVERSE GL Account **/
             
             select CRGL into O_DBACCOUNT from ledgermap where program = 'TIPS' and trantype = 'R'; /*** TIPS REVERSE GL Account **/

             O_NARRATION :=  'TIPS; ' || I_REQREFNO;  
             O_REQCODE := '';      
             O_BRNCODE := v_debibrn || '|' || v_debibrn || '|' || v_creditbrn || '|';
             
             V_COUNT := 0;
              
             V_COUNT := V_COUNT + 1;
             
             Insert into transactions (SUBORGCODE, TRANTYPE, TRANCODE, SYSTEMDATE, TRANSEQ, LEGSL, BRANCHCD, TRANDATE, CHCODE, CHREFNO, DBCR, AMOUNT, TRANCURR, SYSAMOUNT, SYSCURR, ACCOUNTNO, IBAN, SWIFTCD, LEDGERNO, PAYTYPE, CHARGES, CHGCODE, REMARKS, EUSER, EDATE, AUSER, ADATE, CUSER, CDATE, STATUS, INVOICENO, SYSCODE, PAYSL)
             values (I_SUBORG, 'TRANSFER', 'TD', sysdate, V_COUNT, 1, v_debibrn, I_REQDATE, O_CHANNEL, I_REQREFNO, 'D', v_tranamnt, v_debitcurr, O_TRANAMOUNT, v_debitcurr, O_DBACCOUNT, null, null, null, I_PAYTYPE, null, null, O_NARRATION, I_INITIATEBY, sysdate, I_INITIATEBY, sysdate, null, null, 'PENDING', null, 'HP', I_REQSL);

             Insert into transactions (SUBORGCODE, TRANTYPE, TRANCODE, SYSTEMDATE, TRANSEQ, LEGSL, BRANCHCD, TRANDATE, CHCODE, CHREFNO, DBCR, AMOUNT, TRANCURR, SYSAMOUNT, SYSCURR, ACCOUNTNO, IBAN, SWIFTCD, LEDGERNO, PAYTYPE, CHARGES, CHGCODE, REMARKS, EUSER, EDATE, AUSER, ADATE, CUSER, CDATE, STATUS, INVOICENO, SYSCODE, PAYSL)
             values (I_SUBORG, 'TRANSFER', 'TC', sysdate, V_COUNT, 2, v_creditbrn, I_REQDATE, O_CHANNEL, I_REQREFNO, 'C', v_tranamnt, v_debitcurr, O_TRANAMOUNT, v_debitcurr, null, null, null, O_CRACCOUNT, I_PAYTYPE, null, null, O_NARRATION, I_INITIATEBY, sysdate, I_INITIATEBY, sysdate, null, null, 'PENDING', null, 'HP', I_REQSL);             
            
             O_RESULT := 'S';
           Exception when others then
               O_RESULT := 'F';
           end EXCEP;
                     
         end if;
         
         if(I_SERVCD = '2122') then /** TIPS confirms MCB to rereverse the fund  cbs posting  **/
       
           <<EXCEP>>
             BEGIN
               
             select r.chcode, r.d_brncode, r.flow, r.tranamt, r.trancurr into O_CHANNEL, v_debibrn, O_FLOW, O_TRANAMOUNT, v_debitcurr from PAY001 r where 
              r.suborgcode = I_SUBORG and r.paytype = I_PAYTYPE and r.reqsl = I_REQSL;
               
             /*** CBS Account Mapping (Note : Debit : Bank HOLD GL Account & Credit : TIPS Inward Collection Account) **/
          
             v_creditcurr := v_debitcurr;
             v_creditbrn := v_debibrn;
             
             if(v_debibrn is null or v_debibrn = '') then v_debibrn := '1'; end if;       
             if(v_creditbrn is null or v_creditbrn = '') then v_creditbrn := '1';  end if;
             
             v_tranamnt := O_TRANAMOUNT;
             O_DBCURR  := 'TZS';
             
             select CRGL into O_DBACCOUNT from ledgermap where program = 'TIPS' and trantype = 'R'; /*** TIPS Hold GL Account **/
             select DBGL into O_CRACCOUNT from ledgermap where program = 'TIPS' and usergroup = 'I' and dcflg = 'D' and trantype = 'T'; /*** TIPS INWARD COLLECTION **/       
                
             O_NARRATION :=  'TIPS; ' || I_REQREFNO;
             O_REQCODE := '-';      
             O_BRNCODE := v_debibrn || '|' || v_debibrn || '|' || v_creditbrn || '|';
             
             V_COUNT :=0;
              
             V_COUNT := V_COUNT + 1;
           
             Insert into transactions (SUBORGCODE, TRANTYPE, TRANCODE, SYSTEMDATE, TRANSEQ, LEGSL, BRANCHCD, TRANDATE, CHCODE, CHREFNO, DBCR, AMOUNT, TRANCURR, SYSAMOUNT, SYSCURR, ACCOUNTNO, IBAN, SWIFTCD, LEDGERNO, PAYTYPE, CHARGES, CHGCODE, REMARKS, EUSER, EDATE, AUSER, ADATE, CUSER, CDATE, STATUS, INVOICENO, SYSCODE, PAYSL)
             values (I_SUBORG, 'TRANSFER', 'TD', sysdate, V_COUNT, 1, v_debibrn, I_REQDATE, O_CHANNEL, I_REQREFNO, 'D', v_tranamnt, v_debitcurr, O_TRANAMOUNT, v_debitcurr, null, null, null, O_DBACCOUNT, I_PAYTYPE, null, null, O_NARRATION, I_INITIATEBY, sysdate, I_INITIATEBY, sysdate, null, null, 'PENDING', null, 'HP', I_REQSL);

             Insert into transactions (SUBORGCODE, TRANTYPE, TRANCODE, SYSTEMDATE, TRANSEQ, LEGSL, BRANCHCD, TRANDATE, CHCODE, CHREFNO, DBCR, AMOUNT, TRANCURR, SYSAMOUNT, SYSCURR, ACCOUNTNO, IBAN, SWIFTCD, LEDGERNO, PAYTYPE, CHARGES, CHGCODE, REMARKS, EUSER, EDATE, AUSER, ADATE, CUSER, CDATE, STATUS, INVOICENO, SYSCODE, PAYSL)
             values (I_SUBORG, 'TRANSFER', 'TC', sysdate, V_COUNT, 2, v_creditbrn, I_REQDATE, O_CHANNEL, I_REQREFNO, 'C', v_tranamnt, v_debitcurr, O_TRANAMOUNT, v_debitcurr, null, null, null, O_CRACCOUNT, I_PAYTYPE, null, null, O_NARRATION, I_INITIATEBY, sysdate, I_INITIATEBY, sysdate, null, null, 'PENDING', null, 'HP', I_REQSL);
             
             O_RESULT := 'S';
           Exception when others then
               O_RESULT := 'F';
           end EXCEP;
                     
         end if;
            
         if(I_SERVCD = '2110') then
      
             <<EXCEP>>
               BEGIN
                 
               select  w.payload, w.signpayload, w.headerid, w.method, w.uri, w.format, w.protocol into
               O_PAYLOAD, O_SIGNPAYLOAD, O_HEADERID, O_METHOD, O_URI, O_FORMAT, O_PROTOCOL from webservice001 w    
               where w.suborgcode = I_SUBORG and w.syscode = 'HP' and w.chcode = I_PAYTYPE and w.servicecd = I_SERVCD and w.flow = 'O';
                 
               for loop1 in (select * from PAY001 r where r.suborgcode = I_SUBORG and r.paytype = I_PAYTYPE
                and r.TRANREFNO = I_REQREFNO and r.reqsl = I_REQSL) loop
                    
                   O_FLOW := loop1.flow;
                   O_TRANAMOUNT  := loop1.tranamt;     
                   O_CHRGAMOUNT  := loop1.feeamt1;
                   O_CHRGCURR := loop1.feecurr1; 
                   v_debitcurr := loop1.trancurr;
                   v_creditcurr := loop1.trancurr;
                   O_CHANNEL := loop1.chcode;

               end loop;
       
               O_RESULT := 'S';
             Exception when others then
                 O_RESULT := 'F';
             end EXCEP;
                           
         end if;
  
       ELSIF (I_INITIATEBY = 'MCBPAY') THEN  /*** Reversal Req from Internal MCBPAY ***/
     
          <<EXCEP>>
          BEGIN
               
             select ('059' || '-' || 'R' || REPLACE(TO_CHAR(sysdate, 'yyyy-mm-dd'), '-' , '') || trunc(dbms_random.value(100000,999999)) || REF_ID.nextval) into V_REVERSE_REF from dual;
             
             V_REVERSE_REASON := 'INTERNAL SYSTEM ISSUE';
           
             for loop1 in (select * from PAY001 r where r.suborgcode = I_SUBORG
             and r.paytype = I_PAYTYPE and r.REQREFNO = I_REQREFNO and r.reqsl = I_REQSL) loop
             
               O_TRANAMOUNT  := loop1.tranamt;     
               O_CHRGAMOUNT  := loop1.feeamt1;
               O_CHRGCURR := loop1.feecurr1; 
               O_CRACCOUNT := loop1.s_account; /*** MCB customer account **/
               v_debitcurr := loop1.trancurr;
               v_creditcurr := loop1.trancurr;   
               v_creditbrn := loop1.s_brncode;
               O_CHANNEL := loop1.chcode;
             
               O_BRNCODE := '99' || '|' || '99' || '|' || v_creditbrn || '|';

               insert into pay002(SUBORGCODE, CHCODE, PAYTYPE, REQDATE, REQREFNO, TRANREFNO, REQSL, REQTIME, PAYDATE, TRANTYPE, INITIATEBY,
               ORG_AMNT, ORG_CURR, ORG_CHRGAMNT, ORG_CHRGCURR, ORG_REFNO, REV_AMOUNT, REV_CURR, REV_CHRGAMOUNT, REV_CHRGCURR, REV_REFNO, REV_TYPE,
               ISFINAL_REV, REV_CODE, REV_REASON, PAYERID, PAYEEID, TRAN_SWITCHREF, REV_SWITCHREF, rev_status, payer_revref, payee_revref)
               values
               (loop1.suborgcode, loop1.chcode, loop1.paytype, loop1.reqdate, loop1.reqrefno, loop1.tranrefno, loop1.reqsl, loop1.reqtime, loop1.paydate, loop1.trantype, 'TIPS',
               loop1.tranamt, loop1.trancurr, loop1.feeamt1, loop1.feecurr1, loop1.tranrefno, loop1.tranamt, loop1.trancurr, loop1.feeamt1, loop1.feecurr1, null, 'F',
               0, null, V_REVERSE_REASON, loop1.payerid, loop1.payeeref, loop1.switchref, null, null, V_REVERSE_REF , null);

             end loop; 
         
             O_DBCURR  := 'TZS';
             O_REQCODE := '';        
              
             O_RESULT := 'S';
           
         Exception when others then
           O_RESULT := 'F';
         end EXCEP;
             
      ELSE  
          if(I_SERVCD = '2120') then  /*** Approve hold msg request **/
          
           <<EXCEP>>
             BEGIN
                   
                 select j.reason, j.rev_ref into V_REJECT_REASON, V_REVERSE_REF  from job005 j where j.suborgcode = I_SUBORG and j.syscode = 'HP' and  
                 j.paytype = I_PAYTYPE and j.reqdate = I_REQDATE and j.refno = I_REQREFNO and j.reqsl = I_REQSL; 
                      
                  for loop1 in (select * from PAY001 r where r.suborgcode = I_SUBORG and r.chcode = I_INITIATEBY and r.paytype = I_PAYTYPE and
                    r.TRANREFNO = I_REQREFNO and r.reqsl = I_REQSL) loop
               
                     O_FLOW := loop1.flow;
                     O_CHANNEL := loop1.chcode;

                     update pay002 set REQTIME = loop1.reqtime, PAYDATE = loop1.paydate, TRANTYPE = loop1.trantype, INITIATEBY = loop1.chcode,
                     ORG_AMNT = loop1.tranamt, ORG_CURR = loop1.trancurr, ORG_CHRGAMNT = loop1.feeamt1, ORG_CHRGCURR = loop1.feecurr1, ORG_REFNO = loop1.tranrefno, REV_AMOUNT = loop1.tranamt, REV_CURR = loop1.trancurr, REV_CHRGAMOUNT = loop1.feeamt1, REV_CHRGCURR = loop1.feecurr1, REV_TYPE = 'F',
                     ISFINAL_REV = 0, REV_REASON = V_REJECT_REASON, HOLD_STATE = 'REQUESTED', HOLD_AMOUNT = loop1.tranamt, HOLD_CURR = loop1.trancurr, PAYERID = loop1.payerid, PAYEEID = loop1.payeeref, TRAN_SWITCHREF = loop1.switchref, payer_revref = V_REVERSE_REF, 
                     ISREVAPPROVED = 0 where SUBORGCODE = loop1.suborgcode and CHCODE = loop1.chcode and PAYTYPE = loop1.paytype and REQDATE = loop1.reqdate and REQREFNO = loop1.reqrefno and TRANREFNO = loop1.tranrefno and REQSL = loop1.reqsl; 
                     
                  end loop;
                                                  
                 update pay002 w set w.ISHOLDAPPROVED = 1, w.ISREVAPPROVED = 1 where w.suborgcode = I_SUBORG and w.reqsl = I_REQSL and w.PAYTYPE = I_PAYTYPE and w.TRANREFNO = I_REQREFNO;                   
                                               
                 O_RESCD := 'Approved';
                 O_RESDESC := V_REJECT_REASON;
                       
              O_RESULT := 'S';
             
             Exception when others then
               
               O_RESULT := 'F';
             
             end EXCEP; 
            
           end if;
      
           if(I_SERVCD = '2110') then
      
             <<EXCEP>>
               BEGIN
               
               select j.reason, j.rev_ref into V_REVERSE_REASON, V_REVERSE_REF from job005 j where j.suborgcode = I_SUBORG and j.syscode = 'HP' and  
               j.paytype = I_PAYTYPE and j.reqdate = I_REQDATE and j.refno = I_REQREFNO and j.reqsl = I_REQSL; 
                
               for loop1 in (select * from PAY001 r where r.suborgcode = I_SUBORG and r.chcode = I_INITIATEBY
                and r.paytype = I_PAYTYPE and r.reqsl = I_REQSL) loop

                   O_FLOW := loop1.flow;
                   O_TRANAMOUNT  := loop1.tranamt;     
                   O_CHRGAMOUNT  := loop1.feeamt1;
                   O_CHRGCURR := loop1.feecurr1; 
                   O_CRACCOUNT := loop1.s_account;   /*** MCB customer account **/
                   v_creditcurr := loop1.trancurr;
                   v_creditbrn := loop1.s_brncode;
                   O_CHANNEL := loop1.chcode;

               end loop;
         
               /*** CBS Account Mapping (Note : Debit/source Ac : Tips Inward GL Ac & Credit/Destination Ac : MCB Customer Account) **/

               v_tranamnt := O_TRANAMOUNT;
               O_DBCURR  := 'TZS';
               v_debibrn := v_creditbrn;
               
               if(v_debibrn is null or v_debibrn = '') then v_debibrn := '1'; end if;       
               if(v_creditbrn is null or v_creditbrn = '') then v_creditbrn := '1';  end if;
              
               select CRGL into O_DBACCOUNT from ledgermap where program = 'TIPS' and usergroup = 'O' and dcflg = 'C' and trantype = 'T'; /*** TIPS OUTWARD COLLECTION **/

               O_NARRATION :=  'TIPS; ' || I_REQREFNO;  
               O_REQCODE := '';      
               O_BRNCODE := v_debibrn || '|' || v_debibrn || '|' || v_creditbrn || '|';
               
               SELECT NVL(MAX(TRANSEQ),0) INTO V_COUNT FROM TRANSACTIONS T WHERE T.SYSTEMDATE = sysdate;
                
               V_COUNT := V_COUNT + 1;

               Insert into transactions (SUBORGCODE, TRANTYPE, TRANCODE, SYSTEMDATE, TRANSEQ, LEGSL, BRANCHCD, TRANDATE, CHCODE, CHREFNO, DBCR, AMOUNT, TRANCURR, SYSAMOUNT, SYSCURR, ACCOUNTNO, IBAN, SWIFTCD, LEDGERNO, PAYTYPE, CHARGES, CHGCODE, REMARKS, EUSER, EDATE, AUSER, ADATE, CUSER, CDATE, STATUS, INVOICENO, SYSCODE, PAYSL)
               values (I_SUBORG, 'TRANSFER', 'TD', sysdate, V_COUNT, 1, v_creditbrn, I_REQDATE, O_CHANNEL, I_REQREFNO, 'D', v_tranamnt, v_creditcurr, O_TRANAMOUNT, v_creditcurr, null, null, null, O_DBACCOUNT, I_PAYTYPE, null, null, O_NARRATION, I_INITIATEBY, sysdate, I_INITIATEBY, sysdate, null, null, 'PENDING', null, 'HP', I_REQSL);

               Insert into transactions (SUBORGCODE, TRANTYPE, TRANCODE, SYSTEMDATE, TRANSEQ, LEGSL, BRANCHCD, TRANDATE, CHCODE, CHREFNO, DBCR, AMOUNT, TRANCURR, SYSAMOUNT, SYSCURR, ACCOUNTNO, IBAN, SWIFTCD, LEDGERNO, PAYTYPE, CHARGES, CHGCODE, REMARKS, EUSER, EDATE, AUSER, ADATE, CUSER, CDATE, STATUS, INVOICENO, SYSCODE, PAYSL)
               values (I_SUBORG, 'TRANSFER', 'TC', sysdate, V_COUNT, 2, v_creditbrn, I_REQDATE, O_CHANNEL, I_REQREFNO, 'C', v_tranamnt, v_creditcurr, O_TRANAMOUNT, v_creditcurr, O_CRACCOUNT, null, null, null, I_PAYTYPE, null, null, O_NARRATION, I_INITIATEBY, sysdate, I_INITIATEBY, sysdate, null, null, 'PENDING', null, 'HP', I_REQSL);
                
               O_RESULT := 'S';
               
             Exception when others then
               
			   GET STACKED DIAGNOSTICS v_error_stack = PG_EXCEPTION_CONTEXT;
              raise '% : %', sqlstate, sqlerrm; 
             O_RESULT := 'F';
             
             end EXCEP; 
            
        end if; 
                 
     end if;
      
   end if;
   
END;
$$;

alter function proc_o_rev_requestpv(text, text, text, text, text, text, text, out text, out text, out text, out text, out text, out text, out text, out text, out text, out text, out text, out text, out text, out text, out text, out text, out text, out text, out text, out text, out text, out text, out text, out text) owner to postgres;

