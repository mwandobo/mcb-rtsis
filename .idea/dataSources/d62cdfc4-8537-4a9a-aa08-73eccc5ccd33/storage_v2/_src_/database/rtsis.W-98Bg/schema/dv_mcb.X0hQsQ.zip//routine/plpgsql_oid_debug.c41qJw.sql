create function plpgsql_oid_debug(functionoid oid) returns integer
    strict
    language sql
as
$$ SELECT pldbg_oid_debug($1) $$;

alter function plpgsql_oid_debug(oid) owner to postgres;

